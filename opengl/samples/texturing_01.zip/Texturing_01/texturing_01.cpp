#include "utils/glUtils.h"

GLuint fireTexID;

void renderGraphics( void )  {
     
    gluLookAt(0,0,2,0,0,0,0,1,0); 
    
    static float rotAngle = 0;
    
    rotAngle += 0.1;
    
    glRotatef( rotAngle, 0, 1, 0 );
    
    selectTexture(fireTexID);
      
	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex2f( -1.0f, -1.0f);		 
		glTexCoord2f(0.0f,1.0f); glVertex2f(1.0f, -1.0f);
		glTexCoord2f(0.0f,0.0f); glVertex2f(1.0f,1.0f);			
		glTexCoord2f(1.0f,0.0f); glVertex2f(-1.0f,1.0f);			
	glEnd();				
    
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"OpenGL Simple Texturing");
     
      fireTexID = loadJpegAs2DTexture("textures/brickbump.jpg");
      
      glutMainLoop();
}

