#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <math.h>
#include <GL/glew.h>
#include <GL/freeglut.h>

#include "utils/CCamera.h"
#include "utils/textfile.h"
#include "utils/loadjpeg.h"


typedef struct _vector3 {
   	union {
		struct {
			float x,y,z;
		};
		float v[3];
	};     
	
	inline operator float*() { return v; }
	inline operator const float*() const { return v; }
	
	inline float &operator[](int i) { return v[i]; }
	inline const float operator[](int i) const { return v[i]; }
	
} vector3;

typedef struct _vector4 {
   	union {
		struct {
			float x,y,z,w;
		};
		float v[4];
	};     
	
	inline operator float*() { return v; }
	inline operator const float*() const { return v; }
	
	inline float &operator[](int i) { return v[i]; }
	inline const float operator[](int i) const { return v[i]; }
	
} vector4;

typedef struct _ProgramState {
      
      float    time;  
      int      winWidth; 
      int      winHeight;
      GLuint   vertexShader;
      GLuint   fragmentShader;
      GLuint   program;
      GLuint   texture0ID;
      vector3  cameraPos;
      vector3  light;
      vector4  plane;
      vector4  sphere_0;
      vector4  sphere_1;
      vector4  sphere_2;
      bool     pause;
      vector3  scnCameraPos;
      int      rLevel;
      int      mainWindow;
      int      raytraceWindow;
      int      OpenGLWindow;
      int      traceWindow;
      int      frame;
      int      gtime;
      int      timebase;
      char     FPS[30];      
      CCamera  Camera;
      int      mouseX;
      int      mouseY;
      bool     shootRay;
} programState;

programState ps;

void loadShaders();
void loadTextures();
void enableShader();
void disableShader();
void setShaderParameters();
void setupLight();
void setupRedMaterial();
void setupGreenMaterial();
void setupBlueMaterial();
void setOrthographicProjection();
void drawtextAt(float x, float y, void *font,char *string);

void renderSceneMain() {
 
	glutSetWindow(ps.mainWindow);
	glClearColor(0.3f, 0.3f, 0.5f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);    	
	glutSwapBuffers();
}

void renderSceneRayTrace() {

    glutSetWindow(ps.raytraceWindow);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);      
    
    glLoadIdentity();       
    gluLookAt(0, 0, 25, 
              0, 0, 0, 
              0, 1, 0);
              
	glColor3f (1.0, 1.0, 1.0);

    //ps.cameraPos.x = ps.Camera.Pos.x;
    //ps.cameraPos.y = ps.Camera.Pos.y;
    //ps.cameraPos.z = ps.Camera.Pos.z;

   enableShader();
   setShaderParameters();
    
    glPushMatrix();
        glTranslatef(15,0,0);
    	glBegin(GL_QUADS);
        	glVertex2f(-20, -10);
        	glVertex2f(20, -10);
        	glVertex2f(20, 10);
        	glVertex2f(-20, 10);
    	glEnd();
	glPopMatrix();  
     	
	disableShader();    
    
    glColor3f(0,1,0);
    drawtextAt(20, 20, GLUT_BITMAP_HELVETICA_12, "GPU Raytrace window"); 
    drawtextAt(20, 40, GLUT_BITMAP_HELVETICA_12, ps.FPS);
    
    char msg[128];     
    
    sprintf(msg,"Raytrace level: [%d]  - Press 1,2,3,4 to change", ps.rLevel+1);
    drawtextAt(20, 70, GLUT_BITMAP_HELVETICA_12, msg);

      
    glutSwapBuffers();                
}

void renderSceneOpenGL() {

    glutSetWindow(ps.OpenGLWindow);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glLoadIdentity();    
    
   gluLookAt(ps.Camera.Pos.x, ps.Camera.Pos.y, ps.Camera.Pos.z,
             ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z,
             ps.Camera.Up.x, ps.Camera.Up.y, ps.Camera.Up.z);
              
   setupLight();         
	
   glPushMatrix();
       glEnable(GL_TEXTURE_2D);
       glBindTexture(GL_TEXTURE_2D, ps.texture0ID);           
        
        glRotatef(30,1,0,0);             
        
    	glBegin(GL_QUADS);
         	glNormal3f(0.0, 1.0, 0.0);
        	glTexCoord2f(0.0f, 0.0f);  glVertex3f(-50, 0 ,-80);
        	glTexCoord2f(8.0f, 0.0f);  glVertex3f(50,  0 ,-80);
        	glTexCoord2f(8.0f, 8.0f);  glVertex3f(50,  0 , ps.scnCameraPos.z);
        	glTexCoord2f(0.0f, 8.0f);  glVertex3f(-50, 0 , ps.scnCameraPos.z);
    	glEnd();
    	glDisable(GL_TEXTURE_2D);
	glPopMatrix(); 
	
	glPushMatrix();
	    setupBlueMaterial();           
    	glTranslatef(ps.sphere_0.x,ps.sphere_0.y,ps.sphere_0.z);
    	glutSolidSphere(3,64,64);
   	glPopMatrix(); 

	glPushMatrix();
	    setupRedMaterial();
    	glTranslatef(ps.sphere_1.x,ps.sphere_1.y,ps.sphere_1.z);
    	glutSolidSphere(ps.sphere_1.w,64,64);
   	glPopMatrix(); 

	glPushMatrix();
     	setupGreenMaterial();
    	glTranslatef(ps.sphere_2.x,ps.sphere_2.y,ps.sphere_1.z);
    	glutSolidSphere(1,64,64);
   	glPopMatrix();
   	
   	glDisable(GL_LIGHTING);
   	drawtextAt(20, 15, GLUT_BITMAP_HELVETICA_12, "OpenGL render window");
    drawtextAt(20, 30, GLUT_BITMAP_HELVETICA_12, ps.FPS);    
    
    glutSwapBuffers();                    
}

void renderSceneTrace() {

    glutSetWindow(ps.traceWindow);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();       
    gluLookAt(ps.Camera.Pos.x, ps.Camera.Pos.y, ps.Camera.Pos.z,
              ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z,
              ps.Camera.Up.x, ps.Camera.Up.y, ps.Camera.Up.z);

   glPushMatrix();       
        glRotatef(30, 1,0,0);             

        glColor4f(1,1,1,0.5);
        glEnable(GL_BLEND);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        
    	glBegin(GL_LINES);
         for(int x=0;x<25;x++)  {      
                 
          glVertex3f(-50,0, -80 + x*4 ); 	
          glVertex3f(50, 0,-80 + x*4 ); 	
          
          glVertex3f(-50 + x*4, 0,-80); 	
          glVertex3f(-50 + x*4, 0, ps.scnCameraPos.z); 	          
         }          
    	glEnd();
    	
    glDisable(GL_BLEND);	
	glPopMatrix(); 

	glPushMatrix();
	    glColor3f(0,0,1);    
    	glTranslatef(ps.sphere_0.x,ps.sphere_0.y,ps.sphere_0.z);
    	glutWireSphere(3,32,32);
   	glPopMatrix(); 

	glPushMatrix();
	    glColor3f(1,0,0);           
    	glTranslatef(ps.sphere_1.x,ps.sphere_1.y,ps.sphere_1.z);
    	glutWireSphere(ps.sphere_1.w,32,32);
   	glPopMatrix(); 

	glPushMatrix();
     	glColor3f(0,1,0);           
    	glTranslatef(ps.sphere_2.x,ps.sphere_2.y,ps.sphere_1.z);
    	glutWireSphere(1,32,32);
   	glPopMatrix(); 
     
    glColor3f(1,1,1);
    drawtextAt(20, 15, GLUT_BITMAP_HELVETICA_12, "Raytrace simulation window");
    drawtextAt(20, 30, GLUT_BITMAP_HELVETICA_12, ps.FPS);
     
    glutSwapBuffers();                   
}

void renderSceneAll() {    
	
    static int cTime = 0; 
   
    SleepEx(1,FALSE);
    
    if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/80 )  return;
    
    cTime = glutGet(GLUT_ELAPSED_TIME);	
    ps.light.x = 20 * sin(ps.time / 3);
    ps.light.y = 20 + cos(ps.time / 3);       

    ps.sphere_1.x   = -1 + 3* sin(ps.time/2);
    ps.sphere_1.y   =  cos(ps.time/2);

    ps.sphere_2.x   = - 3* sin(ps.time/2);
    ps.sphere_2.y   = - 2* cos(ps.time/2);
                
    ps.time += ps.pause ? 0 : 0.05;
		
	ps.frame++;
	ps.gtime=glutGet(GLUT_ELAPSED_TIME);
	
		if (ps.gtime - ps.timebase > 1000) {
			sprintf(ps.FPS,"FPS: %4.2f",ps.frame*1000.0/(ps.gtime-ps.timebase));
			ps.timebase = ps.gtime;		
			ps.frame = 0;
    }		
    
    
    renderSceneMain();     
	renderSceneOpenGL();
	renderSceneTrace();
	renderSceneRayTrace();
}

void initOpenGL() {
     
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	
    glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
}

void initPS(void) {
	
   	glewInit();
	
	loadShaders();
	loadTextures();    

    ps.scnCameraPos.x = 0;
    ps.scnCameraPos.y = 0;
    ps.scnCameraPos.z = 20;
	
    ps.cameraPos.x = 0;
    ps.cameraPos.y = 0;
    ps.cameraPos.z = 16;
    
    ps.light.x = 0;
    ps.light.y = 0;
    ps.light.z = 20;
    
    ps.plane.v[0] = 0;
    ps.plane.v[1] = 2;
    ps.plane.v[2] = 1;
    ps.plane.v[3] = 1;
    
    ps.sphere_0.x = 5;
    ps.sphere_0.y = 0;
    ps.sphere_0.z = 5;
    ps.sphere_0.w = 3;

    ps.sphere_1.x = -1;
    ps.sphere_1.y = 0;
    ps.sphere_1.z = 10;
    ps.sphere_1.w = 2;

    ps.sphere_2.x = -1;
    ps.sphere_2.y = 1;
    ps.sphere_2.z = 9;
    ps.sphere_2.w = 1;
    
    ps.time     = 0;
    ps.pause    = false; 
    ps.timebase = 0;
    ps.rLevel   = 4;
    
    ps.Camera.SetCamera(0.0f, 0.0f, 20.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
    ps.Camera.CalculateTime();
    
    ps.shootRay = false;
}


void renderBitmapString(float x, float y, void *font,char *string) {
 
		
  char *c;
  glRasterPos2f(x, y);
 
  for (c=string; *c != '\0'; c++) {
    glutBitmapCharacter(font, *c);
  }
}


void resetPerspectiveProjection() {
     
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void setOrthographicProjection() {

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, ps.winWidth, 0, ps.winHeight/2);
	glScalef(1, -1, 1);
	glTranslatef(0, -ps.winHeight/2, 0);
	glMatrixMode(GL_MODELVIEW);
}

void drawtextAt(float x, float y, void *font,char *string) {

	setOrthographicProjection();
	glPushMatrix();
	glLoadIdentity();
	
	renderBitmapString(x,y,font,string); 
	
	glPopMatrix();
	resetPerspectiveProjection();    
}


void setupRedMaterial() {
     
    GLfloat mat_ambient[]  = { 0.1745, 0.01175, 0.01175, 0.55 };
    GLfloat mat_diffuse[]  = { 0.61424, 0.04136, 0.04136, 0.55 };
    GLfloat mat_specular[] = { 0.727811, 0.626959, 0.626959, 0.55 };

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);

	glMaterialf(GL_FRONT,  GL_SHININESS, 76.8);                  
}

void setupGreenMaterial() {
         
    GLfloat mat_ambient[]  = { 0.0215, 0.1745, 0.0215, 0.55 };
    GLfloat mat_diffuse[]  = { 0.07568, 0.61424, 0.07568, 0.55 };
    GLfloat mat_specular[] = { 0.633, 0.727811, 0.633, 0.55 };

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);

	glMaterialf(GL_FRONT,  GL_SHININESS, 76.8);             
     
}

void setupBlueMaterial() {

    GLfloat mat_ambient[]  = { 0.0215, 0.0215, 0.1745,  0.55 };
    GLfloat mat_diffuse[]  = { 0.07568, 0.07568, 0.61424, 0.55 };
    GLfloat mat_specular[] = { 0.633, 0.633, 0.727811, 0.55 };

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);

	glMaterialf(GL_FRONT,  GL_SHININESS, 70);                  
}


void setupLight() {
     
    GLfloat lightAmb[] = {0.3f, 0.3f, 0.3f, 1.3f};
    GLfloat lightDif[] = {1.0f, 1.0f, 1.0f, 1.0f};
    GLfloat lightSpec[] = {1.0f, 1.0f, 1.0f, 1.0f};
    GLfloat lightPos[] = {ps.light.x, ps.light.y, ps.light.z, 0.0f};
    
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDif);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpec);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);		

	glEnable(GL_LIGHT0);								
	glEnable(GL_LIGHTING);	
}

void changeSize2(int w, int h) {
     
	float ratio = 1.0f * w / h;
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
    glViewport(0, 0, w, h);

	gluPerspective(45,ratio,0.1,1000);
	
	glMatrixMode(GL_MODELVIEW);
}

void reshape(int w, int h) {                 
     	
    int border = 5;

	if(h == 0)
		h = 1;

    ps.winWidth   = w;      
    ps.winHeight  = h;

	
	glutSetWindow(ps.traceWindow);
	glutPositionWindow(border,border);
	glutReshapeWindow(w/2-border*3/2, h/2 - border*3/2);
	changeSize2(w/2-border*3/2,h/2 - border*3/2);

	
	glutSetWindow(ps.OpenGLWindow);
	glutPositionWindow((w+border)/2,border);
	glutReshapeWindow(w/2-border*3/2, h/2 - border*3/2);
	changeSize2(w/2-border*3/2,h/2 - border*3/2);

	glutSetWindow(ps.raytraceWindow);
	glutPositionWindow( border,(h+border)/2);
	glutReshapeWindow(w-border*3/2,h/2 - border*3/2);
	changeSize2(w-border*3/2,h/2 - border*3/2);	
}

void setShaderParameters() {
     
	int paramLoc = glGetUniformLocationARB( ps.program, "camera" );
	glUniform3fvARB( paramLoc, 1, ps.cameraPos );

	paramLoc = glGetUniformLocationARB(ps.program, "light");
	glUniform3fvARB(paramLoc, 1, ps.light);

	paramLoc = glGetUniformLocationARB(ps.program, "plane");
	glUniform4fvARB(paramLoc, 1, ps.plane);     
	
	paramLoc = glGetUniformLocationARB(ps.program, "sphere_0");
	glUniform4fvARB(paramLoc, 1, ps.sphere_0);     	

	paramLoc = glGetUniformLocationARB(ps.program, "sphere_1");
	glUniform4fvARB(paramLoc, 1, ps.sphere_1);     	
	
	paramLoc = glGetUniformLocationARB(ps.program, "sphere_2");
	glUniform4fvARB(paramLoc, 1, ps.sphere_2);     	

	paramLoc = glGetUniformLocationARB(ps.program, "rLevel");
    glUniform1iARB(paramLoc, ps.rLevel)
;     		
}

void disableShader() {

   glDisable(GL_VERTEX_PROGRAM_ARB);
   glDisable(GL_FRAGMENT_PROGRAM_ARB);
     
   glUseProgramObjectARB(0); 
}

void enableShader() {
     
	glEnable(GL_VERTEX_PROGRAM_ARB);
	glEnable(GL_FRAGMENT_PROGRAM_ARB);
    		
	glUseProgramObjectARB(ps.program); 
	glBindProgramARB(GL_VERTEX_PROGRAM_ARB,ps.vertexShader);
	glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB,ps.fragmentShader);     
}

void loadTextures() {

	int				width,height;
	unsigned char	*data;

   GLfloat envColor[] = {1.0f, 1.0f, 1.0f, 1.0f};

   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );	
   glTexEnvfv( GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR,  envColor);	
   glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,  GL_REPLACE);	
	
   glGenTextures(1,&ps.texture0ID);
   glBindTexture(GL_TEXTURE_2D,ps.texture0ID);
     
   if((data = LoadJPEG("../textures/raytrace.jpg",&width,&height))) {

		gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);
		free(data);	 
   }
}


void printShaderInfoLog(GLhandleARB obj)
{
	int infologLength = 0;
	int charsWritten  = 0;
	char *infoLog;

	glGetObjectParameterivARB(obj, GL_OBJECT_INFO_LOG_LENGTH_ARB,
										 &infologLength);

	if (infologLength > 0)
	{
		infoLog = (char *)malloc(infologLength);
		glGetInfoLogARB(obj, infologLength, &charsWritten, infoLog);
				printf("\nInfoLog:\n--------------\n%s\n",infoLog);
		free(infoLog);
	}
}

bool checkShaderStatus() {
     
	int status;
	
	glGetObjectParameterivARB(ps.vertexShader, GL_OBJECT_COMPILE_STATUS_ARB, &status);
	if (status == 1) 
       printf("Vertex shader successfully compiled.\n");
	else {
       printf("Failed compiling vertex shader.\n"); 
       printShaderInfoLog(ps.vertexShader);
     }
	
	glGetObjectParameterivARB(ps.vertexShader, GL_OBJECT_LINK_STATUS_ARB, &status);
	if (status == 1) 
      printf("Vertex shader successfully linked.\n");
	else 
      printf("Failed linking vertex shader.\n");
	
	glGetObjectParameterivARB(ps.fragmentShader, GL_OBJECT_COMPILE_STATUS_ARB, &status);
	
	if (status == 1) 
       printf("Fragment shader successfully compiled.\n");
	else {
       printf("Failed compiling fragment shader.\n"); 
       printShaderInfoLog(ps.fragmentShader);
    }
	
	glGetObjectParameterivARB(ps.fragmentShader, GL_OBJECT_LINK_STATUS_ARB, &status);
	
	if (status == 1) 
      printf("Fragment shader successfully linked.\n");
	else 
      printf("Failed linking fragment shader.\n");
     
}

void loadShaders() {
     
    char *vs = NULL,*fs = NULL,*fs2 = NULL;
     
   	ps.vertexShader   = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
	ps.fragmentShader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

	vs = textFileRead("../shaders/raytrace_01.vert");
	fs = textFileRead("../shaders/raytrace_01.frag");
	
	const char * ff = fs;
	const char * vv = vs;

	glShaderSourceARB( ps.vertexShader, 1, &vv, NULL );
	glShaderSourceARB( ps.fragmentShader, 1, &ff, NULL );

    free(vs);free(fs);
    
  	glCompileShaderARB( ps.vertexShader );
	glCompileShaderARB( ps.fragmentShader );

	ps.program = glCreateProgramObjectARB();

	glAttachObjectARB( ps.program, ps.fragmentShader );
	glAttachObjectARB( ps.program, ps.vertexShader );
	
	glLinkProgramARB( ps.program );
    glUseProgramObjectARB( ps.program );	
    
    checkShaderStatus();
}

void keyboard(unsigned char key, int x, int y) {                                          
     
    ps.Camera.CalculateTime();
    
	switch (key) {
	  case 27: 
		  exit(0);
		  break;
      case	'w':
         ps.Camera.MoveCamera(UP);
         break;  
      case	's':
         ps.Camera.MoveCamera(DOWN);
         break;  
      case	'a':
         ps.Camera.RotateCamera(CVector4(ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z),RIGHT, 0, 1, 0); 
         break;  
      case	'd':
          ps.Camera.RotateCamera(CVector4(ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z),LEFT, 0, 1, 0); 
         break;  
      case	'q':
          ps.Camera.RotateCamera(CVector4(ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z),UP, 1, 0, 0);
         break;  
      case	'e':
          ps.Camera.RotateCamera(CVector4(ps.Camera.View.x, ps.Camera.View.y, ps.Camera.View.z),DOWN, 1, 0, 0);
         break;           
      case ' ':
           ps.pause = !ps.pause; 
           break;
      case	'1':
         ps.rLevel=0;
         break;  
      case	'2':
         ps.rLevel=1;
         break;  
      case	'3':
         ps.rLevel=2;
         break;  
      case	'4':
         ps.rLevel=3;
         break;           
   }
}

void mouseMotion(int x,int y) {
     
	ps.mouseX = x;
	ps.mouseX = y;

	glutPostRedisplay();
}


void mouseClick( int button, int state, int posX, int posY ) {
     
	if( state == GLUT_DOWN ) {
		ps.mouseX = posX;
		ps.mouseY = posY;
		ps.shootRay = !ps.shootRay;
	}
	
	glutPostRedisplay();
}
	
int main(int argc, char** argv) {

	int border = 5;
   	int w    = 1000;
	int h    = 600;
    
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(w,h);
	glutInitWindowPosition(0, 0);
	
	ps.mainWindow = glutCreateWindow("GPU Raytrace 1.0");
   
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);
	
	glutDisplayFunc(renderSceneMain);
			
	ps.OpenGLWindow = glutCreateSubWindow(ps.mainWindow,  border,border,w/2-border*3/2, h/2 - border*3/2 );
	glutDisplayFunc(renderSceneOpenGL);
	loadTextures();	
    initOpenGL();		  

	ps.traceWindow = glutCreateSubWindow(ps.mainWindow, (w+border)/2,border,w/2-border*3/2,h/2 - border*3/2 );
	glutDisplayFunc(renderSceneTrace);
    glutMouseFunc(mouseClick);
	glutMotionFunc(mouseMotion);
		
	ps.raytraceWindow = glutCreateSubWindow(ps.mainWindow, border,(h+border)/2,w-2*border, h/2 - border*3/2);
	glutDisplayFunc(renderSceneRayTrace);
	initPS();

	glutIdleFunc(renderSceneAll);		
     
	glutMainLoop();

	return 0;
}
