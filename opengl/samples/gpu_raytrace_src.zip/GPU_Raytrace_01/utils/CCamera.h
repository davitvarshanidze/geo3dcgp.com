/*
   Class Name:

      CCamera.

   Created by:

      Allen Sherrod (Programming Ace of www.UltimateGameProgramming.com).

   Description:

      This class represents a camera in a 3D scene.
*/


#ifndef CCAMERA_H
#define CCAMERA_H

#include<math.h>                          // Math header that allows us to use cos() and sin().
#include"CQuaternion.h"                   // Quaternion class.
#include"CVector.h"                       // Vector class.

#define UP              1.0f              // Forward speed.
#define DOWN            -1.0f             // Backward speed.
#define LEFT            1.0f              // Left speed.
#define RIGHT           -1.0f             // Right speed.
#define STRAFE_LEFT     -1.0f             // Left straft speed.
#define STRAFE_RIGHT    1.0f              // Right straft speed.


class CCamera
{
   public:
      CCamera();

      void SetCamera(float x, float y, float z,
                     float xv, float yv, float zv,
                     float xu, float yu, float zu);

      void MoveCamera(float direction);
      void UpdateCamera(CVector4 Dir, float speed);
      void StrafeCam(float direction);
      void CalculateStrafe();
      void RotateCamera(float AngleDir, float xSpeed,
                        float ySpeed, float zSpeed);
      void RotateCamera(CVector4 point, float AngleDir,
                        float xSpeed, float ySpeed, float zSpeed);
      void RotateByMouse(int mousePosX, int mousePosY,
                         int midX, int midY);
      void CalculateTime();

      CVector4 Pos;                                   // Camera position.
      CVector4 View;                                  // Look at position.
      CVector4 Up;                                    // Up direction.
      CVector4 Strafe;                                // Strafe direction.
      float currentRotationAngle;                     // Keeps us from going too far up or down.
      float frameInterval;                            // Used with time based movements.
};

#endif


// Copyright October 2004
// All Rights Reserved!
// Allen Sherrod
// ProgrammingAce@UltimateGameProgramming.com
// www.UltimateGameProgramming.com