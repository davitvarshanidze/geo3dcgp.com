/*
   Class Name:

      CCamera.

   Created by:

      Allen Sherrod (Programming Ace of www.UltimateGameProgramming.com).

   Description:

      This class represents a camera in a 3D scene.
*/


#include"CCamera.h"
#include"windows.h"


CCamera::CCamera()
{
   // Initialize variables...
   frameInterval = 0.0f;
   currentRotationAngle = 0;
}


void CCamera::SetCamera(float x, float y, float z,
                        float xv, float yv, float zv,
                        float xu, float yu, float zu)
{
   // Here we set the camera to the values sent in to us.  This is mostly used to set up a
   // default position.
   Pos = CVector4(x, y, z);
   View = CVector4(xv, yv, zv);
   Up = CVector4(xu, yu, zu);
}


void CCamera::MoveCamera(float direction)
{
   // First we need to get the direction at which we are looking.
   CVector4 LookDirection;

   // The look direction is the view (where we are looking) minus the position (where we are).
   LookDirection = View - Pos;

   // Normalize the direction.
   LookDirection.Normal();

   // Call UpdateCamera to move our camera in the direction we want.
   UpdateCamera(LookDirection, direction);
}


void CCamera::UpdateCamera(CVector4 Dir, float speed)
{
   // We use our time based movement when we update the camera.
   speed = speed * frameInterval;

   // Move the camera on the X and Z axis.  Don't do y to keep camera on the ground.
   Pos.x += Dir.x * speed;
   //Pos.y += Dir.y * speed;
   Pos.z += Dir.z * speed;

   // Move the view along with the position
   View.x += Dir.x * speed;
   //View.y += Dir.y * speed;
   View.z += Dir.z * speed;
}


void CCamera::StrafeCam(float direction)
{
   // Calculate strafe then update camera.
   CalculateStrafe();
   UpdateCamera(Strafe, direction);
}


void CCamera::CalculateStrafe()
{
   CVector4 Dir;

   // Strafing is just like moving the camera forward and backward.  First we will get the
   // direction we are looking.
   Dir = View - Pos;

   // Normalize the direction.
   Dir.Normal();

   // Get the cross product of the direction we are looking and the up direction.
   Strafe.CrossProduct(Dir, Up);
}


void CCamera::RotateCamera(float AngleDir, float xSpeed, float ySpeed, float zSpeed)
{
	CQuaternion qRotation, qView, qNewView;

   // Create the rotation quaternion based on the axis we are rotating on.
   qRotation.Rotatef(AngleDir, xSpeed, ySpeed, zSpeed);

   // Create the view quaternion.  This will be the direction of the view and position.
   qView.x = View.x - Pos.x;
   qView.y = View.y - Pos.y;
   qView.z = View.z - Pos.z;
   qView.w = 0;

   // Create the resulting quaternion by multiplying the rotation quat by the view quat
   // then multiplying that by the conjugate of the rotation quat.
   qNewView = ((qRotation * qView) * qRotation.Conjugate());

   // Update the view information by adding the position to the resulting quaternion.
   View.x = Pos.x + qNewView.x;
   View.y = Pos.y + qNewView.y;
   View.z = Pos.z + qNewView.z;
}


void CCamera::RotateCamera(CVector4 point, float AngleDir, float xSpeed, float ySpeed, float zSpeed)
{
	CQuaternion qRotation, qPos, qNewPos;

   // Create the rotation quaternion based on the axis we are rotating on.
   qRotation.Rotatef(AngleDir, xSpeed, ySpeed, zSpeed);

   // Create the pos quaternion.  This will be the direction of the center point and position.
   qPos.x = Pos.x - point.x;
   qPos.y = Pos.y - point.y;
   qPos.z = Pos.z - point.z;
   qPos.w = 0;

   // Create the resulting quaternion by multiplying the rotation quat by the pos quat
   // then multiplying that by the conjugate of the rotation quat.
   qNewPos = ((qRotation * qPos) * qRotation.Conjugate());

   // Update the position information by adding the position to the resulting quaternion.
   Pos.x = View.x + qNewPos.x;
   Pos.y = View.y + qNewPos.y;
   Pos.z = View.z + qNewPos.z;
}


void CCamera::RotateByMouse(int mousePosX, int mousePosY, int midX, int midY)
{
	float yDirection = 0.0f;         // Direction angle.
	float yRotation = 0.0f;          // Rotation angle.

	// If the mouseX and mouseY are at the middle of the screen then we can't rotate the view.
	if((mousePosX == midX) && (mousePosY == midY))
      return;

	// Next we get the direction of each axis.  We divide by a value to get a smaller value back.
	yDirection = (float)((midX - mousePosX)) / 20.0f;		
	yRotation = (float)((midY - mousePosY)) / 20.0f;		

	// We use curentRotX to help use keep the camera from rotating too far in either direction.
	currentRotationAngle -= yRotation;

	// Stop the camera from going to high...
	if(currentRotationAngle > 30.0f)
      {
		   currentRotationAngle = 30.0f;
         return;
      }

	// Stop the camera from going to low...
	if(currentRotationAngle < -30.0f)
		{
         currentRotationAngle = -30.0f;
         return;
      }

   // Next we get the axis which is a perpendicular vector of the view direction and up values.
   // We use the cross product of that to get the axis then we normalize it.
   CVector4 Dir, Axis;

   // Get the Direction of the view.
   Dir = View - Pos;

   // Get the cross product of the direction and the up.
   Axis.CrossProduct(Dir, Up);

   Axis.Normal();

   // Rotate the camera.
   RotateCamera(yRotation, Axis.x, Axis.y, Axis.z);
   RotateCamera(yDirection, 0, 1, 0);
}


void CCamera::CalculateTime()
{
   static float lastFrameTime = 0.0f;// Last frame's time.

   // Get the time in milliseconds (we convert to second by * 0.001).
   float currentTime = timeGetTime() * 0.001f;

   // Calculate the frame interval by the current time minus the last frame's time.
   frameInterval = currentTime - lastFrameTime;
   lastFrameTime = currentTime;
}


// Copyright October 2004
// All Rights Reserved!
// Allen Sherrod
// ProgrammingAce@UltimateGameProgramming.com
// www.UltimateGameProgramming.com