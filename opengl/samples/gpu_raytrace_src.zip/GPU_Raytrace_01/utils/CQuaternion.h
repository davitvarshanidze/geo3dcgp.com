/*
   Class Name:

      CQuaternion.

   Created by:

      Allen Sherrod (Programming Ace of www.UltimateGameProgramming.com).

   Description:

      This class is used to create a quaternion to be used with rotations.
*/


#ifndef CQUATERNION_H
#define CQUATERNION_H

#define PI 3.141592654                                      // Define for PI.
#define GET_RADIANS(degree) (float)((degree * PI) / 180.0f)   // Will convert degrees to radians.

#include<math.h>                                            // Math header file.


class CQuaternion 
{
   public:
      CQuaternion()
         {
            // Initialize each member variables.
            x = y = z = 0.0f;
            w = 1.0f;
         }
	   
	   CQuaternion(float xAxis, float yAxis, float zAxis, float wAxis) 
	      {
            // Initialize each member variables.
		      x = xAxis; y = yAxis; z = zAxis;
            w = wAxis;
	      }

      void operator=(const CQuaternion &q)
         {
            // This will make this quaternion equal to q.
            w = q.w; x = q.x; y = q.y; z = q.z;
         }

      CQuaternion operator*(const CQuaternion &q)
         {
            // To multiply a quaternion you must first do the dot and cross product
            // of the 2 quaternions then add/subract them to a result.
            CQuaternion result;

            result.x = w * q.x + x * q.w + y * q.z - z * q.y;
            result.y = w * q.y - x * q.z + y * q.w + z * q.x;
            result.z = w * q.z + x * q.y - y * q.x + z * q.w;
            result.w = w * q.w - x * q.x - y * q.y - z * q.z;

            return result;
         }

      CQuaternion Conjugate()
         {
            // The Conjugate is basically all axis negated but the w.
            return CQuaternion(-x, -y, -z, w);
         }

	   void Rotatef(float amount, float xAxis, float yAxis, float zAxis)
         {
            // Pretty much what is going on here is that if there is any axis that is not
            // a 0 or a 1 (meaning its not normalized) then we want to normalize it.
            // I created a if statement because I thought this would be better than normalizing
            // it every time this function is called, which would result in a lot of expensive
            // sqrt() call.  This is just in case the user forgot to use only normalized values.
            if((xAxis != 0 && xAxis != 1) ||
               (yAxis != 0 && yAxis != 1) ||
               (zAxis != 0 && zAxis != 1))
            {
               float length = (float)sqrt(xAxis * xAxis + yAxis * yAxis + zAxis * zAxis);
               xAxis /= length; yAxis /= length; zAxis /= length;
            }

            // Convert the angle degrees into radians.
            float angle = GET_RADIANS(amount);

            // Call this once for optimization, just like using the if statement to determine if
            // we should normalize.
	         float sine = (float)sin(angle / 2.0f);

            // Create the quaternion.
	         x = xAxis * sine;
	         y = yAxis * sine;
	         z = zAxis * sine;
            w = (float)cos(angle / 2.0f);

            // Normalize the quaternion.
            float length = 1 / (float)sqrt(x * x + y * y + z * z + w * w);
            x *= length;
            y *= length;
            z *= length;
         }

	   void CreateMatrix(float *pMatrix)
         {
            // This function will take in a 4x4 matrix and add the quaternion values to it.
            // The matrix equation for this was mentioned in QuaternionTutorial.cpp intro (top
            // section).

            // Error checking...
	         if(!pMatrix)
               return;

	         // Calculate the first row.
	         pMatrix[0]  = 1.0f - 2.0f * (y * y + z * z); 
	         pMatrix[1]  = 2.0f * (x * y + z * w);
	         pMatrix[2]  = 2.0f * (x * z - y * w);
	         pMatrix[3]  = 0.0f;  

	         // Calculate the second row.
	         pMatrix[4]  = 2.0f * (x * y - z * w);  
	         pMatrix[5]  = 1.0f - 2.0f * (x * x + z * z); 
	         pMatrix[6]  = 2.0f * (z * y + x * w);  
	         pMatrix[7]  = 0.0f;  

	         // Calculate the third row.
	         pMatrix[8]  = 2.0f * (x * z + y * w);
	         pMatrix[9]  = 2.0f * (y * z - x * w);
	         pMatrix[10] = 1.0f - 2.0f * (x * x + y * y);  
	         pMatrix[11] = 0.0f;  

	         // Calculate the fourth row.
	         pMatrix[12] = 0;  
	         pMatrix[13] = 0;  
	         pMatrix[14] = 0;  
	         pMatrix[15] = 1.0f;
         }

	   float x, y, z, w;                      // x, y , z, and w axis.
};

#endif


// Copyright September 2003
// All Rights Reserved!
// Allen Sherrod
// ProgrammingAce@UltimateGameProgramming.com
// www.UltimateGameProgramming.com