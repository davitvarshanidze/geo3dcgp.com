#include <GL/freeglut.h>
#include <stdio.h>
#include <stdlib.h>

void init(void) {
     
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_SMOOTH);
   glEnable(GL_DEPTH_TEST);  
}

void display(void)
{      
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
    static int cTime = 0; 
   
    SleepEx(1,FALSE);
    
    if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/80 ) return;
    
    cTime = glutGet(GLUT_ELAPSED_TIME);
   
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
	
    static float rotA   = 0;
    static float lightX = 0;
    static int   sign   = -1;
    
    rotA   += 0.1f;
    lightX += sign*0.1f;
    
   GLfloat position[] = {lightX,4.0,3.0,0.0};
   
   if (lightX>7 || lightX<-7 ) sign=-sign;
   
   glLightfv(GL_LIGHT0,GL_POSITION,position);

    glRotatef(rotA, 0,1,0);
    

    GLfloat mat_ambient[]  = { 0.1745, 0.01175, 0.01175, 0.55};
    GLfloat mat_diffuse[]  = { 0.61424, 0.04136, 0.04136, 0.55};
    GLfloat mat_specular[]  = { 0.727811, 0.626959, 0.626959, 0.55};
    GLfloat mat_emission[]  = { 0.1, 0.0, 0.0, 1.0 };
    GLfloat mat_Shininess = 76.8;
    
    glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    glMaterialf(GL_FRONT,  GL_SHININESS, mat_Shininess);
    
    glutSolidSphere(2.0f,200,200);
    
    glutSwapBuffers();
}

void reshape (int w, int h)
{
    glViewport(0, 0, w, h);

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 60.0, (GLdouble)w / (GLdouble)h, 0.1, 100.0);

    gluLookAt( 0.0, 2.0, 5.0,  // Camera position
               0.0, 0.0, 0.0,   // Look-at point
               0.0, 1.0, 0.0 ); // Up vector
 
   glEnable(GL_LIGHTING);
     
   GLfloat ambient[]  = {0.0,0.0,0.0,0.5};
   GLfloat diffuse[]  = {1.0,1.0,1.0,1.0};
   GLfloat specular[] = {1.0,1.0,1.0,1.0};
   GLfloat position[] = {0.0,4.0,0.0,0.0};
   
   glLightfv(GL_LIGHT0,GL_AMBIENT,ambient);
   glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuse);
   glLightfv(GL_LIGHT0,GL_SPECULAR,specular);
   glLightfv(GL_LIGHT0,GL_POSITION,position);
 
   glEnable(GL_LIGHT0); 
}

void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_DEPTH);
   glutInitWindowSize (640, 480); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display); 
   glutIdleFunc(display); 
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0;
}

