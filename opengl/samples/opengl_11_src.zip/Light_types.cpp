#include <GL/freeglut.h>
#include <math.h>
#include <stdlib.h>

int g_Light_type = 0;
// Mesh properties...
const int   g_nNumVertsAlongX   = 32;
const int   g_nNumVertsAlongZ   = 32;
const float g_fMeshLengthAlongX = 10.0f;
const float g_fMeshLengthAlongZ = 10.0f;

const int g_nMeshVertCount = (g_nNumVertsAlongX-1) * (g_nNumVertsAlongZ-1) * 6;

struct Vertex
	{
	// GL_C4F_N3F_V3F
	float r, g, b, a;
	float nx, ny, nz;
	float x, y, z;
	};

Vertex g_meshVertices[g_nMeshVertCount];

GLfloat light_position[]	= { 0.0, 5.0, 2.0 };
GLfloat mat_ambient[]		= { 0.4, 0.4, 0.4, 1.0 };
GLfloat mat_diffuse[]		= { 0.4, 0.4, 0.4, 1.0 };
GLfloat mat_specular[]		= { 0.0, 0.0, 0.0, 1.0 };
GLfloat mat_emission[]		= { 0.0, 0.0, 0.0, 0.0 };	
GLfloat mat_Shininess		= {0};	


void createMesh( void )
	{
	// Compute position deltas for moving down the X, and Z axis during mesh creation
	const float dX =  (1.0f/(g_nNumVertsAlongX-1));
	const float dZ = -(1.0f/(g_nNumVertsAlongZ-1));

	int i = 0;
	int x = 0;
	int z = 0;

	// These are all the same...
	for( i = 0; i < g_nMeshVertCount; ++i )
		{
		// Mesh tesselation occurs in the X,Z plane, so Y is always zero
		g_meshVertices[i].y = 0.0f;

		g_meshVertices[i].nx = 0.0f;
		g_meshVertices[i].ny = 1.0f;
		g_meshVertices[i].nz = 0.0f;

		g_meshVertices[i].r = 1.0f;
		g_meshVertices[i].g = 1.0f;
		g_meshVertices[i].b = 1.0f;
		}

	//
	// Create all the vertex points required by the mesh...
	//
	// Note: Mesh tesselation occurs in the X,Z plane.
	//

	// For each row of our mesh...
	for( z = 0, i = 0; z < (g_nNumVertsAlongZ-1); ++z )
		{
		// Fill the row with quads which are composed of two triangles each...
		for( x = 0; x < (g_nNumVertsAlongX-1); ++x )
			{
			// First triangle of the current quad
			//   ___ 2
			//  |  /|
			//  |/__|
			// 0     1

			// 0
			g_meshVertices[i].x  = g_fMeshLengthAlongX * x * dX;
			g_meshVertices[i].z  = g_fMeshLengthAlongZ * z * dZ;
			++i;

			// 1
			g_meshVertices[i].x  = g_fMeshLengthAlongX * (x+1.0f) * dX;
			g_meshVertices[i].z  = g_fMeshLengthAlongZ * z * dZ;
			++i;

			// 2
			g_meshVertices[i].x  = g_fMeshLengthAlongX * (x+1.0f) * dX;
			g_meshVertices[i].z  = g_fMeshLengthAlongZ * (z+1.0f) * dZ;
			++i;

			// Second triangle of the current quad
			// 2 ___ 1
			//  |  /|
			//  |/__|
			// 0

			// 0
			g_meshVertices[i].x  = g_fMeshLengthAlongX * x * dX;
			g_meshVertices[i].z  = g_fMeshLengthAlongZ * z * dZ;
			++i;

			// 1
			g_meshVertices[i].x  = g_fMeshLengthAlongX * (x+1.0f) * dX;
			g_meshVertices[i].z  = g_fMeshLengthAlongZ * (z+1.0f) * dZ;
			++i;

			// 2
			g_meshVertices[i].x = g_fMeshLengthAlongX * x * dX;
			g_meshVertices[i].z = g_fMeshLengthAlongZ * (z+1.0f) * dZ;
			++i;
			}
		}
	}


void renderStringAt(float x, float y,void* font, const char* string) {
	glRasterPos2f(x,y);
	char* p = (char*) string;
	while (*p != '\0') glutBitmapCharacter(font, *p++);
}

void resetMaterials() {

	mat_diffuse[0]  = mat_diffuse[1]  = mat_diffuse[2]   = 0.0f;
	mat_specular[0] = mat_specular[1] = mat_specular[2]  = 0.0f;
	mat_ambient[0]  = mat_ambient[1]  = mat_ambient[2]   = 0.0f;
	mat_emission[0] = mat_emission[1] = mat_emission[2]  = 0.0f;
	mat_Shininess   = 0.0f;
}

void init(void) {
	GLfloat diffuse[]		 = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat specular[]		 = { 1.0, 1.0, 1.0, 1.0 };

	glClearColor(0.5, 0.6, 0.8, 0.0);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);

	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glEnable(GL_LIGHTING);
	

	GLfloat diffuse_light1[] = { 0.25f, 0.25f, 0.25f, 1.0f };
	GLfloat position_light1[] = { 0.3f, -0.5f, 0.2f, 0.0f };
	//GLfloat position_light1[] = { 0.3f, -0.5f, -0.2f, 0.0f };
	glLightfv( GL_LIGHT1, GL_DIFFUSE, diffuse_light1 );
	glLightfv( GL_LIGHT1, GL_POSITION, position_light1 );

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	mat_diffuse[0] = 0.0f;	
	mat_diffuse[1] = 1.0f;
	mat_diffuse[2] = 0.0f;

	mat_ambient[0] = 0.5f;	
	mat_ambient[1] = 1.0f;
	mat_ambient[2] = 0.5f;

	mat_specular[0] = 0.5f;	
	mat_specular[1] = 1.0f;
	mat_specular[2] = 0.5f;

	mat_Shininess = 40.0f;

	mat_Shininess = 5.0f;
	createMesh();
}

void display(void) {

	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	glColor3f(1.0,1.0,1.0);
	char msg[128];
	renderStringAt(12,6,GLUT_BITMAP_HELVETICA_18,"Lights 1.0");

	static double dStartTime = glutGet(GLUT_ELAPSED_TIME);
	float fElpasedAppTime = (float)((glutGet(GLUT_ELAPSED_TIME) - dStartTime) * 0.001);

	float x =   sinf( fElpasedAppTime * 2.000f );
	float y =   sinf( fElpasedAppTime * 2.246f );
	float z = -(sinf( fElpasedAppTime * 2.640f ));

	glPushAttrib( GL_LIGHTING_BIT );

	glDisable( GL_LIGHT0 );
	glEnable( GL_LIGHT1 );
	glEnable( GL_LIGHT2 );

	if (g_Light_type == 0) { //Directional

		renderStringAt(12,5,GLUT_BITMAP_HELVETICA_12,"Directional Light");

		GLfloat diffuse_light2[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		GLfloat position_light2[] = { x, y, z, 0.0f };
		glLightfv( GL_LIGHT2, GL_DIFFUSE, diffuse_light2 );
		glLightfv( GL_LIGHT2, GL_POSITION, position_light2 );
	}
	else
	if (g_Light_type == 1) {
		renderStringAt(12,5,GLUT_BITMAP_HELVETICA_12,"Spot Light");
		GLfloat diffuse_light2[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		GLfloat position_light2[] = { 2.0f*x, 2.0f*y, 2.0f*z, 1.0f };
		GLfloat spotDirection_light2[] = { x, y, z };
		GLfloat constantAttenuation_light2[] = { 1.0f };
		glLightfv( GL_LIGHT2, GL_DIFFUSE, diffuse_light2 );
		glLightfv( GL_LIGHT2, GL_POSITION, position_light2 );
		glLightfv( GL_LIGHT2, GL_SPOT_DIRECTION, spotDirection_light2 );
		glLightfv( GL_LIGHT2, GL_CONSTANT_ATTENUATION, constantAttenuation_light2 );
		glLightf( GL_LIGHT2, GL_SPOT_CUTOFF, 45.0f );
		glLightf( GL_LIGHT2, GL_SPOT_EXPONENT, 25.0f );
	} else 
	if (g_Light_type == 2) {
		renderStringAt(12,5,GLUT_BITMAP_HELVETICA_12,"Point Light");
		GLfloat diffuse_light2[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		GLfloat position_light2[] = { 4.5f*x, 4.5f*y, 4.5f*z, 1.0f };
		GLfloat linearAttenuation_light2[] = { 0.4f };
		glLightfv( GL_LIGHT2, GL_DIFFUSE, diffuse_light2 );
		glLightfv( GL_LIGHT2, GL_POSITION, position_light2 );
		glLightfv( GL_LIGHT2, GL_LINEAR_ATTENUATION , linearAttenuation_light2 );
	}
	
	mat_diffuse[0] = 0.0f;	
	mat_diffuse[1] = 1.0f;
	mat_diffuse[2] = 0.0f;

	mat_ambient[0] = 0.5f;	
	mat_ambient[1] = 1.0f;
	mat_ambient[2] = 0.5f;

	mat_specular[0] = 0.5f;	
	mat_specular[1] = 1.0f;
	mat_specular[2] = 0.5f;

	mat_Shininess = 40.0f;

	mat_Shininess = 5.0f;

	//glPolygonMode(GL_FRONT,GL_LINE);
	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf(GL_FRONT,  GL_SHININESS, mat_Shininess);

	glPushMatrix();
	glTranslatef( -5.0f, -5.0f, 5.0f );
	glInterleavedArrays( GL_C4F_N3F_V3F, 0, g_meshVertices );
	glDrawArrays( GL_TRIANGLES , 0, g_nMeshVertCount );
	glPopMatrix();

	// Draw the back wall
	glPushMatrix();
	glTranslatef( 5.0f, -5.0f, 5.0f );
	glRotatef( 90.0f, 0.0f, 0.0f, 1.0f );
	glInterleavedArrays( GL_C4F_N3F_V3F, 0, g_meshVertices );
	glDrawArrays( GL_TRIANGLES , 0, g_nMeshVertCount );
	glPopMatrix();

	// Draw the side wall
	glPushMatrix();
	glTranslatef( -5.0f, -5.0f, -5.0f );
	glRotatef( 90.0f, 1.0f, 0.0f, 0.0f );
	glInterleavedArrays( GL_C4F_N3F_V3F, 0, g_meshVertices );
	glDrawArrays( GL_TRIANGLES , 0, g_nMeshVertCount );
	glPopMatrix();

	mat_emission[0] = 0.1f;	
	mat_emission[1] = 0.1f;
	mat_emission[2] = 0.1f;

	mat_diffuse[0] = 0.5f;	
	mat_diffuse[1] = 0.5f;
	mat_diffuse[2] = 0.5f;

	mat_ambient[0] = 1.0f;	
	mat_ambient[1] = 1.0f;
	mat_ambient[2] = 1.5f;

	mat_specular[0] = 1.0f;	
	mat_specular[1] = 1.0f;
	mat_specular[2] = 1.0f;

	mat_Shininess = 5.0f;

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf(GL_FRONT,  GL_SHININESS, mat_Shininess);

	glLoadIdentity();
	glTranslatef(-1,2,-2);
	glutSolidTeapot(1.0);
	glTranslatef(3,-5,5);
	glutSolidSphere(1.5,32,32);

	glLoadIdentity();
	GLfloat sf_emission[] = { 1.0, 1.0, 1.0, 1.0 };	
	GLfloat sf_ambient[] = { 0.4, 0.4, 0.4, 0.0 };	
	GLfloat sf_specular[] = { 0.4, 0.4, 0.4, 0.0 };	
	GLfloat sf_diffuse[] = { 0.4, 0.4, 0.4, 0.0 };	

	glMaterialfv(GL_FRONT, GL_AMBIENT,  sf_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  sf_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, sf_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION,  sf_emission);

	glTranslatef(x,y,z);
	glutSolidSphere( 0.25f, 15, 15 );

	glPopAttrib();
	glutSwapBuffers();
}

void reshape(int w, int h) {
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,w/h,1,500);
	gluLookAt(-7.0, 7.0, 7.0,  // Camera position
		0.0,-1.2, 0.0,         // Look-at point
		0.0, 1.0, 0.0 );        // Up vector
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void myKeyboard(unsigned char key, int x, int y) {
	switch (key) {
	  case 27:
		  exit(0);
		  break;
	  case ' ':
		  g_Light_type = (g_Light_type + 1)%3;		  
		}

}

void specialkeys( int key, int x, int y ) {
	switch (key) {
  case GLUT_KEY_DOWN:
	  break;
  case GLUT_KEY_UP:
	  break;
  case GLUT_KEY_LEFT:	 
	  break;
  case GLUT_KEY_RIGHT: 	
	  break;
  default:
	  break;
		}
	glutPostRedisplay();
}

int main(int argc, char** argv)
	{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize (800, 600); 
	glutInitWindowPosition (400, 100);
	glutCreateWindow ("Lights 1.0");
	init();
	glutDisplayFunc(display); 
	glutReshapeFunc(reshape);
	glutKeyboardFunc(myKeyboard);
	glutSpecialFunc(specialkeys);
	glutIdleFunc(display);
	glutMainLoop();
	return 0;
}

