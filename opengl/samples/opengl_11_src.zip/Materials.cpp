#include <GL/freeglut.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

float rotX = 0;
float rotY = 0;
float rotZ = 0;

GLfloat position[]		 = { 4.0, 6.0, 8.0, 0.0 };
GLfloat camposition[]	 = { 8.0, 2.0, 14.0 };

GLfloat mat_ambient[]  = { 0.4, 0.4, 0.4, 1.0 };
GLfloat mat_diffuse[]  = { 0.4, 0.4, 0.4, 1.0 };
GLfloat mat_specular[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat mat_emission[] = { 0.0, 0.0, 0.0, 0.0 };	
GLfloat mat_Shininess  = {0};	
GLint	axisList;

//0-R, 1-G, 2-B
int  rMode = -1;
int  model = 0;
bool wireframe = false;

void renderStringAt(float x, float y,void* font, const char* string) {
	glRasterPos2f(x,y);
	char* p = (char*) string;
	while (*p != '\0') glutBitmapCharacter(font, *p++);
}

/*  Initialize material property, light source, lighting model,
*  and depth buffer.
*/
void init(void) 
	{
	GLfloat diffuse[]		 = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat specular[]		 = { 1.0, 1.0, 1.0, 1.0 };

	glClearColor(0.5, 0.6, 0.8, 0.0);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_NORMALIZE);
	
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, position);

	
	glEnable(GL_LIGHT0);

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);

	glMaterialf(GL_FRONT,  GL_SHININESS, mat_Shininess);

	GLfloat sf_em_red[] = { 1.0, 0.0, 0.0, 0.0 };	
	GLfloat sf_em_green[] = { 0.0, 1.0, 0.0, 0.0 };	
	GLfloat sf_em_blue[] = { 0.0, 0.0, 1.0, 0.0 };	

	axisList = glGenLists(1);

	glNewList(axisList,GL_COMPILE);

	glDisable(GL_LIGHT0);
	glLoadIdentity();
	glLineWidth(3.0f);

	glBegin(GL_LINES);	 	
	glMaterialfv(GL_FRONT, GL_EMISSION,  sf_em_red);
	glVertex3f(-10.0f,0.0f,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);
	glVertex3f(9.0f,0.5f,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);
	glVertex3f(9.0f,-0.5f,0.0f);
	glVertex3f(10.0f,0.0f,0.0f);

	glMaterialfv(GL_FRONT, GL_EMISSION,  sf_em_green);
	glVertex3f(0.0f,-10.0f,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);
	glVertex3f(0.5f,9.0f,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);
	glVertex3f(-0.5f,9.0f,0.0f);
	glVertex3f(0.0f,10.0f,0.0f);

	glMaterialfv(GL_FRONT, GL_EMISSION,  sf_em_blue);
	glVertex3f(0.0f,0.0f,-10.0f);
	glVertex3f(0.0f,0.0f,10.0f);
	glVertex3f(0.0f,0.5f,9.0f);
	glVertex3f(0.0f,0.0f,10.0f);
	glVertex3f(0.0f,-0.5f,9.0f);
	glVertex3f(0.0f,0.0f,10.0f);

	glEnd();

	glEnable(GL_LIGHT0);
	glLineWidth(0.5f);

	glEndList();

	

	}

void resetMaterials() {

	mat_diffuse[0]  = mat_diffuse[1]  = mat_diffuse[2]  = mat_diffuse[3]   = 0.0f;
	mat_specular[0] = mat_specular[1] = mat_specular[2] = mat_specular[3]  = 0.0f;
	mat_ambient[0]  = mat_ambient[1]  = mat_ambient[2]  = mat_ambient[3]   = 0.0f;
	mat_emission[0] = mat_emission[1] = mat_emission[2] = mat_emission[3]  = 0.0f;
	mat_Shininess   = 0.0f;
}

void drawText() {

	glLoadIdentity();

	GLfloat em_text[] = { 1.0, 1.0, 1.0, 0.0 };	
	glMaterialfv(GL_FRONT, GL_EMISSION,  em_text);

	char msg[128];
	renderStringAt(-25,19,GLUT_BITMAP_HELVETICA_18,"Materials 1.0");

	sprintf(msg,"Ambient RGB[%.02f,%.02f,%.02f,%.02f] - 'A'",mat_ambient[0], mat_ambient[1], mat_ambient[2], mat_ambient[3]);
	renderStringAt(-25,18,GLUT_BITMAP_HELVETICA_12,msg);

	sprintf(msg,"Diffuse RGB[%.02f,%.02f,%.02f,%.02f] - 'D'",mat_diffuse[0], mat_diffuse[1], mat_diffuse[2], mat_diffuse[3]);
	renderStringAt(-25,17,GLUT_BITMAP_HELVETICA_12,msg);

	sprintf(msg,"Specular RGB[%.02f,%.02f,%.02f,%.02f] - 'S'",mat_specular[0], mat_specular[1], mat_specular[2], mat_specular[3]);
	renderStringAt(-25,16,GLUT_BITMAP_HELVETICA_12,msg);

	sprintf(msg,"Emission RGB[%.02f,%.02f,%.02f,%.02f] - 'E'",mat_emission[0], mat_emission[1], mat_emission[2], mat_emission[3]);
	renderStringAt(-25,15,GLUT_BITMAP_HELVETICA_12,msg);

	sprintf(msg,"Shininess [%.02f] - 'H'",mat_Shininess);
	renderStringAt(-25,14,GLUT_BITMAP_HELVETICA_12,msg);	
}

void drawLightSphere() {

	glLoadIdentity();

	GLfloat sf_emission[] = { 0.0, 0.0, 0.0, 0.0 };	
	GLfloat sf_ambient[] = { 0.4, 0.4, 0.4, 0.0 };	
	GLfloat sf_specular[] = { 0.4, 0.4, 0.4, 0.0 };	
	GLfloat sf_diffuse[] = { 0.4, 0.4, 0.4, 0.0 };	

	if (rMode==-1)
		sf_emission[0]=sf_emission[1]=sf_emission[2] = 1.0;
	else
		sf_emission[rMode] = 1.0;

	glMaterialfv(GL_FRONT, GL_AMBIENT,  sf_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  sf_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, sf_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION,  sf_emission);
	glTranslatef(position[0],position[1],position[2]);
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glutSolidSphere(0.5,16,16);
}

void display(void)
	{
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	drawLightSphere();
	glCallList(axisList);
	drawText();

	glLoadIdentity();

	glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf(GL_FRONT,  GL_SHININESS, mat_Shininess);

	glRotatef(rotX, 1.0,0.0,0.0);
	glRotatef(rotY, 0.0,1.0,0.0);
	glRotatef(rotZ, 0.0,0.0,1.0);

	if (model==0) {
		if (wireframe) {
		  glutWireTeapot(5.0);
		}
		else {
		  glutSolidTeapot(5.0);
		}
	 }
	else if (model==1) {
		if (wireframe) {
			glutWireSphere(5.0,64,64);
			}
		else {
			glutSolidSphere(5.0,64,64);
			}		
	}	
	else if (model==2) {
		if (wireframe) {
			glutWireTorus(2.0, 5.0,64,64);
			}
		else {
			glutSolidTorus(2.0, 5.0,64,64);
			}		
		}
	glutSwapBuffers();
	}

void reshape (int w, int h)
	{
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,w/h,0.1,500);
	gluLookAt(camposition[0],camposition[1],camposition[2],0,0,0,0,1,0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	}


void specialkeys( int key, int x, int y )
	{
	switch (key) {
  case GLUT_KEY_F1:
		resetMaterials();
		mat_diffuse[0] = 1.0f;	
		mat_diffuse[1] = 0.5f;
		mat_diffuse[2] = 0.2f;
		mat_diffuse[3] = 1.0f;
	  break;
  case GLUT_KEY_F2:
	  resetMaterials();
	  mat_diffuse[0] = 0.0f;	
	  mat_diffuse[1] = 1.0f;
	  mat_diffuse[2] = 0.0f;
	  mat_diffuse[3] = 1.0f;

	  mat_ambient[0] = 0.5f;	
	  mat_ambient[1] = 1.0f;
	  mat_ambient[2] = 0.5f;
	  mat_ambient[3] = 1.0f;

	  mat_specular[0] = 0.5f;	
	  mat_specular[1] = 1.0f;
	  mat_specular[2] = 0.5f;
	  mat_specular[3] = 1.0f;

	  mat_Shininess = 40.0f;
	  break;
  case GLUT_KEY_F3:
	  resetMaterials();

	  mat_emission[0] = 0.1f;	
	  mat_emission[1] = 0.1f;
	  mat_emission[2] = 0.1f;

	  mat_diffuse[0] = 0.5f;	
	  mat_diffuse[1] = 0.5f;
	  mat_diffuse[2] = 0.5f;
	  mat_diffuse[3] = 1.0f;

	  mat_ambient[0] = 1.0f;	
	  mat_ambient[1] = 1.0f;
	  mat_ambient[2] = 1.0f;
	  mat_ambient[3] = 1.0f;

	  mat_specular[0] = 1.0f;	
	  mat_specular[1] = 1.0f;
	  mat_specular[2] = 1.0f;
	  mat_specular[3] = 1.0f;

	  mat_Shininess = 5.0f;
	  break;
  case GLUT_KEY_DOWN:
	  position[2]+=0.5;
	  break;
  case GLUT_KEY_UP:
	  position[2]-=0.5;
	  break;
  case GLUT_KEY_LEFT:	 
	  position[0]-=0.5;
	  break;
  case GLUT_KEY_RIGHT: 	
	  position[0]+=0.5;	
	  break;
  default:
	  break;
		}
	glLightfv(GL_LIGHT0, GL_POSITION, position);

	glutPostRedisplay();
	
	}

void myKeyboard(unsigned char key, int x, int y)
	{
	switch (key) {
	  case 27:
		  exit(0);
		  break;	
	  case 'x':
		  rotX = int((rotX + 5))%360;
		  break;
	  case 'y':
		  rotY = int((rotY + 5))%360;
		  break;
	  case 'z':
		  rotZ = int((rotZ + 5))%360;
		  break;
	  case 'w':
			wireframe = !wireframe;
			break;
	  case ' ':
		  rMode++;
		  if (rMode==4) rMode=-1;
		  break;
	  case 'c':
		  model++;		  
		  if (model==3) model=0;
		  break;
	  case 'r':
		resetMaterials();		  
		break;
	  case 'A':
		  if (mat_ambient[0] <= 0.99 && (rMode==-1 || rMode==0)) 
			  mat_ambient[0] += 0.01;
		  if (mat_ambient[1] <= 0.99 && (rMode==-1 || rMode==1)) 
			  mat_ambient[1] += 0.01;
		  if (mat_ambient[2] <= 0.99 && (rMode==-1 || rMode==2)) 
			  mat_ambient[2] += 0.01;			 
		  if (mat_ambient[3] <= 0.99 && (rMode==-1 || rMode==3)) 
			  mat_ambient[3] += 0.01;			 
		  break;
	  case 'a':
		  if (mat_ambient[0] > 0.01 && (rMode==-1 || rMode==0)) 
			  mat_ambient[0] -= 0.01;
		  if (mat_ambient[1] > 0.01 && (rMode==-1 || rMode==1)) 
			  mat_ambient[1] -= 0.01;
		  if (mat_ambient[2] > 0.01 && (rMode==-1 || rMode==2)) 
			  mat_ambient[2] -= 0.01;
		  if (mat_ambient[3] > 0.01 && (rMode==-1 || rMode==3)) 
			  mat_ambient[3] -= 0.01;
		  break;			   
	  case 'D':
		  if (mat_diffuse[0] <= 0.99 && (rMode==-1 || rMode==0)) 
			  mat_diffuse[0] += 0.01;
		  if (mat_diffuse[1] <= 0.99 && (rMode==-1 || rMode==1)) 
			  mat_diffuse[1] += 0.01;
		  if (mat_diffuse[2] <= 0.99 && (rMode==-1 || rMode==2)) 
			  mat_diffuse[2] += 0.01;			 
		  if (mat_diffuse[3] <= 0.99 && (rMode==-1 || rMode==3)) 
			  mat_diffuse[3] += 0.01;			 
		  break;
	  case 'd':
		  if (mat_diffuse[0] > 0.01 && (rMode==-1 || rMode==0)) 
			  mat_diffuse[0] -= 0.01;
		  if (mat_diffuse[1] > 0.01 && (rMode==-1 || rMode==1)) 
			  mat_diffuse[1] -= 0.01;
		  if (mat_diffuse[2] > 0.01 && (rMode==-1 || rMode==2)) 
			  mat_diffuse[2] -= 0.01;
		  if (mat_diffuse[3] > 0.01 && (rMode==-1 || rMode==3)) 
			  mat_diffuse[3] -= 0.01;
		  break;			   
	  case 'S':
		  if (mat_specular[0] <= 0.99 && (rMode==-1 || rMode==0))  
			  mat_specular[0] += 0.01;
		  if (mat_specular[1] <= 0.99 && (rMode==-1 || rMode==1))  
			  mat_specular[1] += 0.01;
		  if (mat_specular[2] <= 0.99 && (rMode==-1 || rMode==2))  
			  mat_specular[2] += 0.01;			  
		  if (mat_specular[3] <= 0.99 && (rMode==-1 || rMode==3))  
			  mat_specular[3] += 0.01;			  
		  break;
	  case 's':
		  if (mat_specular[0] > 0.01 && (rMode==-1 || rMode==0))  
			  mat_specular[0] -= 0.01;
		  if (mat_specular[1] > 0.01 && (rMode==-1 || rMode==1))  
			  mat_specular[1] -= 0.01;
		  if (mat_specular[2] > 0.01 && (rMode==-1 || rMode==2))  
			  mat_specular[2] -= 0.01;			  
		  if (mat_specular[3] > 0.01 && (rMode==-1 || rMode==3))  
			  mat_specular[3] -= 0.01;			  
		  break;
	  case 'E':
		  if (mat_emission[0] < 0.99 && (rMode==-1 || rMode==0))   
			  mat_emission[0] += 0.01;
		  if (mat_emission[1] < 0.99 && (rMode==-1 || rMode==1))   
			  mat_emission[1] += 0.01;
		  if (mat_emission[2] < 0.99 && (rMode==-1 || rMode==2))   
			  mat_emission[2] += 0.01;
		  if (mat_emission[3] < 0.99 && (rMode==-1 || rMode==3))   
			  mat_emission[3] += 0.01;
		  break;
	  case 'e':
		  if (mat_emission[0] > 0.01 && (rMode==-1 || rMode==0))   
			  mat_emission[0] -= 0.01;
		  if (mat_emission[1] > 0.01 && (rMode==-1 || rMode==1))   
			  mat_emission[1] -= 0.01;
		  if (mat_emission[2] > 0.01 && (rMode==-1 || rMode==2))   
			  mat_emission[2] -= 0.01;			  
		  if (mat_emission[3] > 0.01 && (rMode==-1 || rMode==3))   
			  mat_emission[3] -= 0.01;			  
		  break;
	  case 'H':
		  if (mat_Shininess < 100) {
			  mat_Shininess += 0.5;			 
			  }
		  break;
	  case 'h':
		  if (mat_Shininess > 0.0) {
			  mat_Shininess-= 0.5;			 
			  }
		  break;
	  default:
		  break;
	  }
	 glutPostRedisplay();
	}

int main(int argc, char** argv)
	{
	glutInit(&argc, argv);


	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize (800, 600); 
	glutInitWindowPosition (400, 100);
	glutCreateWindow ("Materials 1.0");
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(myKeyboard);
	glutSpecialFunc(specialkeys);
	glutIdleFunc(display);
	glutMainLoop();
	return 0;
	}

