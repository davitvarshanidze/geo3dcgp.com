#include "utils/glUtils.h"

GLuint texID1;
GLuint texID2;
GLuint activeTextID;

GLfloat zPlane[] = { 0.0f, 0.0f, 1.0f, 0.0f };

void renderGraphics( void )  {
     
    gluLookAt(0,0,2.2,0,0,0,0,1,0); 
    
    static float rotAngle = 0;
    
    rotAngle += 0.5;
    
    glRotatef( rotAngle, 1, 1, 1 );
    
    selectTexture(activeTextID);

    glutSolidTorus( 0.3, 0.8, 32, 32 );          
}

/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;     
    case '1':
          activeTextID = texID1;
          enableAutoTexturing(GL_OBJECT_LINEAR, zPlane);
         break;  
    case '2':
          activeTextID = texID1;
          enableAutoTexturing(GL_EYE_LINEAR, zPlane);
         break;  
    case '3':
          activeTextID = texID2;
          enableAutoTexturing(GL_SPHERE_MAP);
         break;  
         
    default:     
      break;
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"OpenGL Sphere Texturing");              
      
      texID1 = loadJpegAs2DTexture("textures/brickbump.jpg");     
      texID2 = loadJpegAs2DTexture("textures/fire.jpg");
       
      activeTextID = texID1;
      enableAutoTexturing(GL_OBJECT_LINEAR, zPlane);
      
      glutMainLoop();
}

