#include <GL/freeglut.h>
#include <stdlib.h>


int FPS=80;
int time;
int timebase=0;

void init(void) 
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glShadeModel (GL_FLAT);
}



void display(void)
{   

    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (1.0, 1.0, 1.0);

    static int cTime = 0; 
   
    SleepEx(1,FALSE);
    
    if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/FPS  ) return;
    
    cTime = glutGet(GLUT_ELAPSED_TIME);
    
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    gluLookAt( 0.0, 2.0, 25.0,  // Camera position
               0.0, 0.0, 0.0,   // Look-at point
               0.0, 1.0, 0.0 ); // Up vector

    float g_fSpeedmodifier = 1.0f;
    
    static float fSunSpin    = 0.0f;    
    static float fEarthSpin  = 0.0f;    
    static float fEarthOrbit = 0.0f;
    static float fMoonSpin   = 0.0f;
    static float fMoonOrbit  = 0.0f;
    
    fSunSpin    -= 0.1f;   
    
    fEarthSpin  -= 1.0f;
    fEarthOrbit -= 0.2f;
        
    fMoonSpin   -= 0.5f;
    fMoonOrbit  -= 2.0f;

    //SUN       
    glPushMatrix();
    {
        glRotatef( fSunSpin, 0.0f, 1.0f, 0.0f ); 
        glScalef( 5.0f, 5.0f, 5.0f );            

        glColor4f( 1.0f, 1.0f, 0.0f, 1.0f );
        glutWireSphere( 1.0f, 30, 20 );
    }
    glPopMatrix();


    glPushMatrix();
    {
        glRotatef( fEarthOrbit, 0.0f, 1.0f, 0.0f ); 
        glTranslatef( 0.0f, 0.0f, -12.0f );         
        glRotatef( fEarthSpin, 0.0f, 1.0f, 0.0f );  

        glColor4f( 0.0f, 0.0f, 1.0f, 1.0f );
        glutWireSphere( 1.0f, 10, 20 );
    }
    glPopMatrix();

    //MOON
    glPushMatrix();
    {
        glRotatef( fEarthOrbit, 0.0f, 1.0f, 0.0f ); 
        glTranslatef( 0.0f, 0.0f, -12.0f );         
        
        glRotatef( fMoonOrbit, 0.0f, 1.0f, 0.0f );  
        glTranslatef( 0.0f, 0.0f, -2.0f );          
        glRotatef( fMoonSpin, 0.0f, 1.0f, 0.0f );   

        glColor4f( 1.0f, 1.0f, 1.0f, 1.0f );
        glutWireSphere( 0.5f, 8, 8 );
    }
    glPopMatrix();
    glutSwapBuffers();
}

void reshape (int w, int h)
{
    glViewport(0, 0, w, h);

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 45.0, (GLdouble)w / (GLdouble)h, 0.1, 100.0);

}

void keyboard (unsigned char key, int x, int y)
{
   switch (key) {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB );
   glutInitWindowSize (800, 600); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display); 
   glutIdleFunc(display); 
   glutReshapeFunc(reshape);
   glutKeyboardFunc(keyboard);
   glutMainLoop();
   return 0;
}
