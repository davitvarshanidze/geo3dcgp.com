#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <GL/glew.h>
#include <GL/freeglut.h>

#include "routines/textfile.h"
#include "routines/loadjpeg.h"

//Global variables
GLuint    g_fragmentShader;
GLuint    g_vertexShader;
GLuint    g_program;
GLuint    g_tex1;
GLuint    g_tex2;
int       g_time = 0;
GLuint    g_time_loc;

void changeSize(int w, int h) {

	if(h == 0)
		h = 1;

	float ratio = 1.0* w / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
    glViewport(0, 0, w, h);

	gluPerspective(60,ratio,1,1000);
	glMatrixMode(GL_MODELVIEW);

	glClearColor(0.2f, 0.3f, 0.5f, 0.5f);
}


GLUquadricObj	*quadic;



void renderScene(void) {
     
    float  lpos[4] = {1,0.5,1,0};
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
    static int   sign = 1;	
    static float angle = 0;

	glLoadIdentity();
	gluLookAt(0.0,0.0,200.0, 
              0.0,0.0,-1.0, 
              0.0f,1.0f,0.0f);
    glRotatef(angle,1,0,0);
    
    angle += 0.5f;
    
    if (angle == 360 ) angle = 0;
    
    if (g_time > 5000)  { 
      g_time = 0;  	  
      sign = -sign;
    }
    
    g_time += 10;       
        
    glUniform1iARB(g_time_loc, sign*g_time);

    gluSphere(quadic, 70.0f, 32, 16);
    //glutSolidTeapot(70);
    
	glutSwapBuffers();
}

void processNormalKeys(unsigned char key, int x, int y) {

	if (key == 27) 
		exit(0);
}

void loadTextures() {

	int				width,height;
	unsigned char	*data;

   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
   glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );	
	
   glGenTextures(1,&g_tex1);
   glBindTexture(GL_TEXTURE_2D,g_tex1);
     
   if((data = LoadJPEG("../Textures/brickbump.jpg",&width,&height))) {

		gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);
		free(data);	 
   }

   glGenTextures(1,&g_tex2);
   glBindTexture(GL_TEXTURE_2D,g_tex2);

   if((data = LoadJPEG("../Textures/fire.jpg",&width,&height))) {
		gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);
		free(data);	 
   }

	quadic = gluNewQuadric();								
	gluQuadricNormals(quadic, GL_SMOOTH);					
	gluQuadricTexture(quadic, GL_TRUE);	   
}

void PrintInfoLog(GLhandleARB obj)
{
	int infologLength = 0;
	int charsWritten  = 0;
	char *infoLog;

	glGetObjectParameterivARB(obj, GL_OBJECT_INFO_LOG_LENGTH_ARB,
										 &infologLength);

	if (infologLength > 0)
	{
		infoLog = (char *)malloc(infologLength);
		glGetInfoLogARB(obj, infologLength, &charsWritten, infoLog);
				printf("\nInfoLog:\n--------------\n%s\n",infoLog);
		free(infoLog);
	}
}

void setShaderParams() {
  
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, g_tex1);
    int tex1_loc = glGetUniformLocationARB(g_program, "tex1");
    glUniform1iARB(tex1_loc, 0);
    
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, g_tex2);
    int tex2_loc = glGetUniformLocationARB(g_program, "tex2");
    glUniform1iARB(tex2_loc, 1); 
  
    g_time_loc = glGetUniformLocationARB(g_program,"TIME_FROM_INIT");   
}

void loadShaders() {

   char *vs = NULL,*fs = NULL,*fs2 = NULL;

	g_vertexShader   = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
	printf("Vertex Shader handle is %d\n",g_vertexShader);
	g_fragmentShader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
	printf("Fragment Shader handle is %d\n",g_fragmentShader);

	vs = textFileRead("../shaders/mtext.vert");
	fs = textFileRead("../shaders/mtext.frag");

	const char * ff = fs;
	const char * vv = vs;

	glShaderSourceARB( g_vertexShader, 1, &vv, NULL );
	glShaderSourceARB( g_fragmentShader, 1, &ff, NULL );

	free(vs);free(fs);

	glCompileShaderARB(g_vertexShader);
	glCompileShaderARB(g_fragmentShader);

	g_program = glCreateProgramObjectARB();
    printf("Program handle is %d\n",g_program);
	glAttachObjectARB(g_program,g_fragmentShader);
	glAttachObjectARB(g_program,g_vertexShader);

	glLinkProgramARB(g_program);
	glUseProgramObjectARB(g_program);
	
	int status;
	glGetObjectParameterivARB(g_vertexShader, GL_OBJECT_COMPILE_STATUS_ARB, &status);
	if (status == 1) 
      printf("Vertex shader successfully compiled.\n");
	else {
           printf("Failed compiling vertex shader.\n"); 
           PrintInfoLog(g_vertexShader);}
	
	glGetObjectParameterivARB(g_vertexShader, GL_OBJECT_LINK_STATUS_ARB, &status);
	if (status == 1) 
      printf("Vertex shader successfully linked.\n");
	else 
      printf("Failed linking vertex shader.\n");
	
	glGetObjectParameterivARB(g_fragmentShader, GL_OBJECT_COMPILE_STATUS_ARB, &status);
	
	if (status == 1) 
       printf("Fragment shader successfully compiled.\n");
	else {
       printf("Failed compiling fragment shader.\n"); 
       PrintInfoLog(g_fragmentShader);
    }
	
	glGetObjectParameterivARB(g_fragmentShader, GL_OBJECT_LINK_STATUS_ARB, &status);
	
	if (status == 1) 
      printf("Fragment shader successfully linked.\n");
	else 
      printf("Failed linking fragment shader.\n");
}


int main(int argc, char **argv) {
    
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(800,600);
	glutCreateWindow("[OpenGL] - Animated Shader Multitexturing 1.0");

	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutKeyboardFunc(processNormalKeys);

	glEnable(GL_DEPTH_TEST);
	glewInit();
	
   if (GLEW_ARB_vertex_shader && GLEW_ARB_fragment_shader)
     printf("Ready for GLSL\n");
   else {
     printf("Not totally ready :( \n");
     exit(1);
    }
	
	loadTextures();
	loadShaders();
	setShaderParams();

	glutMainLoop();

	return 0;
}


