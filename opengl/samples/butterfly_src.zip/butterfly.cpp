
#include <stdio.h>   
#include <stdlib.h>
#include <gl/freeglut.h>   // The GL Utility Toolkit (GLUT) Header

#include "utils/loadjpeg.h"


// User Defined Variables (From original NeHe's Lesson 38)
GLuint texture[3];												// Storage For 3 Textures

struct object													// Create A Structure Called Object
{
	int   tex;													// Integer Used To Select Our Texture
	float x;													// X Position
	float y;													// Y Position
	float z;													// Z Position
	float yi;													// Y Increase Speed (Fall Speed)
	float spinz;												// Z Axis Spin
	float spinzi;												// Z Axis Spin Speed
	float flap;													// Flapping Triangles :)
	float fi;													// Flap Direction (Increase Value)
};

object obj[50];													// Create 50 Objects Using The Object Structure

void SetObject(int loop)										// Sets The Initial Value Of Each Object (Random)
{
	obj[loop].tex=rand()%3;										// Texture Can Be One Of 3 Textures
	obj[loop].x=rand()%34-17.0f;								// Random x Value From -17.0f To 17.0f
	obj[loop].y=18.0f;											// Set y Position To 18 (Off Top Of Screen)
	obj[loop].z=-((rand()%30000/1000.0f)+10.0f);				// z Is A Random Value From -10.0f To -40.0f
	obj[loop].spinzi=(rand()%10000)/5000.0f-1.0f;				// spinzi Is A Random Value From -1.0f To 1.0f
	obj[loop].flap=0.0f;										// flap Starts Off At 0.0f;
	obj[loop].fi=0.05f+(rand()%100)/1000.0f;					// fi Is A Random Value From 0.05f To 0.15f
	obj[loop].yi=0.001f+(rand()%1000)/10000.0f;					// yi Is A Random Value From 0.001f To 0.101f
}

void LoadGLTextures()											// Creates Textures From Bitmaps In The Resource File
{
     
    char            texPath[128];                     
    int				width,height;
	unsigned char	*data;

   glGenTextures(3, &texture[0]);
   
   for(int i=0; i<3; i++) {

   glPixelStorei(GL_UNPACK_ALIGNMENT,4);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);	
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR); 
	
    glBindTexture(GL_TEXTURE_2D, texture[i]);
    sprintf(texPath, "../textures/Butterfly%d.jpg", i+1 ); 
    
   if((data = LoadJPEG(texPath,&width,&height))) {

		gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);
		free(data);	 
   }
   
}
}


bool init(void)
{
	LoadGLTextures();											
	
	glClearColor (0.0f, 0.0f, 0.0f, 0.5f);						// Black Background
	glClearDepth (1.0f);										// Depth Buffer Setup
	glDepthFunc (GL_LEQUAL);									// The Type Of Depth Testing (Less Or Equal)
	glDisable(GL_DEPTH_TEST);									// Disable Depth Testing
	glShadeModel (GL_SMOOTH);									// Select Smooth Shading
	glHint (GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);			// Set Perspective Calculations To Most Accurate
	glEnable(GL_TEXTURE_2D);									// Enable Texture Mapping
	glBlendFunc(GL_ONE,GL_SRC_ALPHA);							// Set Blending Mode (Cheap / Quick)
	glEnable(GL_BLEND);											// Enable Blending

	for (int loop=0; loop<50; loop++)							// Loop To Initialize 50 Objects
	{
		SetObject(loop);										// Call SetObject To Assign New Random Values
	}

	return true;
}

// Our Rendering Is Done Here
void render(void)   
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);			// Clear Screen And Depth Buffer
    glLoadIdentity();											// Reset The Current Modelview Matrix


	for (int loop=0; loop<50; loop++)							// Loop Of 50 (Draw 50 Objects)
	{
		glLoadIdentity ();										// Reset The Modelview Matrix
		glBindTexture(GL_TEXTURE_2D, texture[obj[loop].tex]);	// Bind Our Texture
		glTranslatef(obj[loop].x,obj[loop].y,obj[loop].z);		// Position The Object
		glRotatef(45.0f,1.0f,0.0f,0.0f);						// Rotate On The X-Axis
		glRotatef((obj[loop].spinz),0.0f,0.0f,1.0f);			// Spin On The Z-Axis


		glBegin(GL_TRIANGLES);									// Begin Drawing Triangles
			// First Triangle												
			glTexCoord2f(1.0f,0.0f); glVertex3f( -1.0f, -1.0f, 0.0f);		 
			glTexCoord2f(1.0f,1.0f); glVertex3f(1.0f, -1.0f, obj[loop].flap);
			glTexCoord2f(0.0f,1.0f); glVertex3f(1.0f,1.0f, 0.0f);			

			// Second Triangle
			glTexCoord2f(1.0f,0.0f); glVertex3f( -1.0f, -1.0f, 0.0f);		
			glTexCoord2f(0.0f,1.0f); glVertex3f(1.0f,1.0f, 0.0f);			
			glTexCoord2f(0.0f,0.0f); glVertex3f( -1.0f,1.0f, obj[loop].flap);

		glEnd();												// Done Drawing Triangles

		obj[loop].y-=obj[loop].yi;								// Move Object Down The Screen
		obj[loop].spinz+=obj[loop].spinzi;						// Increase Z Rotation By spinzi
		obj[loop].flap+=obj[loop].fi;							// Increase flap Value By fi

		if (obj[loop].y<-18.0f)									// Is Object Off The Screen?
		{
			SetObject(loop);									// If So, Reassign New Values
		}

		if ((obj[loop].flap>1.0f) || (obj[loop].flap<-1.0f))	// Time To Change Flap Direction?
		{
			obj[loop].fi=-obj[loop].fi;							// Change Direction By Making fi = -fi
		}
	}

	Sleep(15);													// Create A Short Delay (15 Milliseconds)

    // Swap The Buffers To Become Our Rendering Visible
    glutSwapBuffers ( );
}

// Our Reshaping Handler (Required Even In Fullscreen-Only Modes)
void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);     // Select The Projection Matrix
	glLoadIdentity();                // Reset The Projection Matrix
	// Calculate The Aspect Ratio And Set The Clipping Volume
	if (h == 0) h = 1;
	gluPerspective(80, (float)w/(float)h, 1.0, 5000.0);
	glMatrixMode(GL_MODELVIEW);      // Select The Modelview Matrix
	glLoadIdentity();                // Reset The Modelview Matrix
}

// Our Keyboard Handler (Normal Keys)
void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
		case 27:        // When Escape Is Pressed...
			exit(0);    // Exit The Program
		break;          // Ready For Next Case
		default:        // Now Wrap It Up
		break;
	}
}

// Our Keyboard Handler For Special Keys (Like Arrow Keys And Function Keys)
void special_keys(int a_keys, int x, int y)
{
	switch (a_keys) {
		case GLUT_KEY_F1:
			// We Can Switch Between Windowed Mode And Fullscreen Mode Only
		break;
		default:
		break;
	}
}

// Main Function For Bringing It All Together.
int main(int argc, char** argv)
{
	//ask_gamemode();                                  // Ask For Fullscreen Mode
	glutInit(&argc, argv);                           // GLUT Initializtion
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);     // Display Mode (Rgb And Double Buffered)
	
    glutInitWindowSize(800, 600);                    // Window Size If We Start In Windowed Mode
	glutCreateWindow("Butterflye 1.0");             // Window Title 
	
	init();                                          // Our Initialization
	glutDisplayFunc(render);                         // Register The Display Function
	glutReshapeFunc(reshape);                        // Register The Reshape Handler
	glutKeyboardFunc(keyboard);                      // Register The Keyboard Handler
	glutSpecialFunc(special_keys);                   // Register Special Keys Handler
	glutIdleFunc(render);                            // We Render In Idle Time
	glutMainLoop();                                  // Go To GLUT Main Loop
	return 0;
}
