#include "utils/glUtils.h"

GLuint BalltxID;
GLuint EnvtxID;
GLuint WalltxID;
GLuint WoodtxID;
GLuint CratexID;
GLuint SwirltexID;

GLUquadricObj	*quadic;

// Light Parameters
static GLfloat LightAmb[] = {0.3f, 0.3f, 0.3f, 1.0f};	// Ambient Light
static GLfloat LightDif[] = {1.0f, 1.0f, 1.0f, 1.0f};	// Diffuse Light
static GLfloat LightPos[] = {4.0f, 4.0f, 6.0f, 1.0f};	// Light Position

#define BALL_NUM 20

typedef struct _balls {

	float ballY;
	float ballZ;
	float ballX;
	float ballYVel;
	float ballZVel;
	float ballXVel;
	float ballScale;

	float rotA;
	float rotV;
	} balls;

balls Balls[BALL_NUM]; 

float rotS		= 0;

void drawFarFloor() {

	glBindTexture(GL_TEXTURE_2D, WoodtxID);
	glBegin(GL_QUADS);						
	glNormal3f(0.0, 0.0, 1.0);	

	glTexCoord2f(0.0f, 1.0f);				
	glVertex3f(-3.0, -0.6, 0.0);				

	glTexCoord2f(0.0f, 0.0f);				
	glVertex3f(-3.0, 0.6,0.0);				

	glTexCoord2f(1.0f, 0.0f);				
	glVertex3f( 3.0, 0.6,0.0);				

	glTexCoord2f(1.0f, 1.0f);				
	glVertex3f( 3.0, -0.6, 0.0);				
	glEnd();								
}

void drawFloor() {

	glBindTexture(GL_TEXTURE_2D, WalltxID);
	glBegin(GL_QUADS);						
	glNormal3f(0.0, 1.0, 0.0);				
	glTexCoord2f(0.0f, 1.0f);				
	glVertex3f(-3.0, 0.0, 6.0);				

	glTexCoord2f(0.0f, 0.0f);				
	glVertex3f(-3.0, 0.0,-6.0);				

	glTexCoord2f(1.0f, 0.0f);				
	glVertex3f( 3.0, 0.0,-6.0);				

	glTexCoord2f(1.0f, 1.0f);				
	glVertex3f( 3.0, 0.0, 6.0);				
	glEnd();								
	}

void drawBall(int ballID) {

	glPushMatrix(); 
	glTranslatef(Balls[ballID].ballX, Balls[ballID].ballY, Balls[ballID].ballZ );
	glRotatef(Balls[ballID].rotA,1,1,1);
	glScalef(Balls[ballID].ballScale,Balls[ballID].ballScale,Balls[ballID].ballScale);
	glBindTexture(GL_TEXTURE_2D, BalltxID);
	gluSphere(quadic, 0.35f, 32, 16);
	glBindTexture(GL_TEXTURE_2D, EnvtxID);
	glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
	gluSphere(quadic, 0.35f, 32, 16);
	glDisable(GL_TEXTURE_GEN_S);						
	glDisable(GL_TEXTURE_GEN_T);						
	glDisable(GL_BLEND);	
	glPopMatrix();
}


void renderGraphics( void )  {
     
    gluLookAt(0,4,10,0,0,0,0,1,0); 

	glRotatef(rotS,0,1,0);
	drawFarFloor();
	for(int i=0;i<BALL_NUM;i++)
		drawBall(i);	

	glColorMask(0,0,0,0);

	glEnable(GL_STENCIL_TEST);
	glStencilFunc(GL_ALWAYS, 1, 1);
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
	glDisable(GL_DEPTH_TEST);


	drawFloor();

	double eqr[] = {0.0f,-1.0f, 0.0f, 0.0f};
	glEnable(GL_DEPTH_TEST);							
	glColorMask(1,1,1,1);								
	glStencilFunc(GL_EQUAL, 1, 1);						
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);				
	glEnable(GL_CLIP_PLANE0);							
	glClipPlane(GL_CLIP_PLANE0, eqr);					

	glPushMatrix();						
	glScalef(1.0f, -1.0f, 1.0f);		
	glLightfv(GL_LIGHT0, GL_POSITION, LightPos);

	for(int i=0;i<BALL_NUM;i++)
		drawBall(i);	
	glPopMatrix();								

	glDisable(GL_CLIP_PLANE0);					
	glDisable(GL_STENCIL_TEST);					

	glLightfv(GL_LIGHT0, GL_POSITION, LightPos);
	glEnable(GL_BLEND);							
	glDisable(GL_LIGHTING);						
	glColor4f(1.0f, 1.0f, 1.0f, 0.8f);			
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	drawFloor();									
	glEnable(GL_LIGHTING);							
	glDisable(GL_BLEND);			


	for(int i=0;i<BALL_NUM;i++) {
		Balls[i].ballX += Balls[i].ballXVel;
		Balls[i].ballY += Balls[i].ballYVel;
		Balls[i].ballZ += Balls[i].ballZVel;	

		Balls[i].rotA = Balls[i].rotA + Balls[i].rotV;
		if  ( Balls[i].rotA > 360 ) Balls[i].rotA = 0;

		if (Balls[i].ballX < -2.7  || Balls[i].ballX > 2.7 )  {
			Balls[i].ballXVel *= -1;
			Balls[i].rotV = (float)rand() / (RAND_MAX + 1) * 10;
			}

		if (Balls[i].ballY < 0.3  || Balls[i].ballY > 2.7 )  {
			Balls[i].ballYVel *= -1;
			Balls[i].rotV = (float)rand() / (RAND_MAX + 1) * 10;
			}

		if (Balls[i].ballZ < -6.0 || Balls[i].ballZ > 6.4 )  {
			Balls[i].ballZVel *= -1;
			Balls[i].rotV = (float)rand() / (RAND_MAX + 1) * 10;
			}
		}

	rotS = (rotS + 0.2);
	if (rotS > 360) rotS = 0;
    
    SleepEx(1,false);    
         
}


void initProgram(void) {

    glClearColor(0.5, 0.6, 0.8, 0.0);
    
	glMatrixMode(GL_MODELVIEW);							
    
	EnvtxID    = loadJpegAs2DTexture("textures/Envroll.jpg");
	WalltxID   = loadJpegAs2DTexture("textures/Envwall.jpg");
	BalltxID   = loadJpegAs2DTexture("textures/Ball.jpg");
	WoodtxID   = loadJpegAs2DTexture("textures/Woodfloor.jpg");
	CratexID   = loadJpegAs2DTexture("textures/Crate.jpg");
	SwirltexID = loadJpegAs2DTexture("textures/Swirl.jpg");

	glShadeModel(GL_SMOOTH);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);	

	glEnable(GL_TEXTURE_2D);							

	glClearDepth(1.0f);
	glClearStencil(0);

	glLightfv(GL_LIGHT0, GL_AMBIENT, LightAmb);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, LightDif);
	glLightfv(GL_LIGHT0, GL_POSITION, LightPos);		

	glEnable(GL_LIGHT0);								
	glEnable(GL_LIGHTING);								

	quadic = gluNewQuadric();								
	gluQuadricNormals(quadic, GL_SMOOTH);					
	gluQuadricTexture(quadic, GL_TRUE);						

	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	


	srand(time(NULL));

	for(int i=0;i<BALL_NUM;i++) {

		Balls[i].ballY		= 0.4 + (float)rand() / (RAND_MAX + 1) * 2;
		Balls[i].ballZ		= -4 + (float)rand() / (RAND_MAX + 1) * 10;
		Balls[i].ballX		= -2.5 + (float)rand() / (RAND_MAX + 1) * 5;
		Balls[i].ballYVel 	= -0.05 + (float)rand() / (RAND_MAX + 1) * 0.2;
		Balls[i].ballZVel 	= -0.05 + (float)rand() / (RAND_MAX + 1) * 0.2;
		Balls[i].ballXVel 	= -0.05 + (float)rand() / (RAND_MAX + 1) * 0.2;

		Balls[i].rotA = -90 + rand() / (RAND_MAX + 1) * 90;
		Balls[i].rotV = (float)rand() / (RAND_MAX + 1) * 0.5;
		Balls[i].ballScale = 0.2 + (float)rand() / (RAND_MAX + 1) * 0.8;
		}
}

/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;             
    default:     
      break;
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_STENCIL ,"OpenGL Balls");              
      
      initProgram();
      
      glutMainLoop();
}

