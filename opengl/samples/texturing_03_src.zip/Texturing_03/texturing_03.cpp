#include "utils/glUtils.h"

GLuint texID;

void renderGraphics( void )  {
     
    gluLookAt(0,0,2,0,0,0,0,1,0); 
        
    selectTexture(texID);
    
    glPushMatrix();
    glRotatef(180,1,0,0);  
	glBegin(GL_QUADS);								
		glTexCoord2f(0.0f,0.0f); glVertex2f(-1.0f, -1.0f);		 
		glTexCoord2f(3.0f,0.0f); glVertex2f(1.0f, -1.0f);
		glTexCoord2f(3.0f,3.0f); glVertex2f(1.0f, 1.0f);			
		glTexCoord2f(0.0f,3.0f); glVertex2f(-1.0f,1.0f);		
	glEnd();	
    glPopMatrix();			
	
    glPushMatrix();
    glRotatef(180,1,0,0);  
    glTranslatef(-1.7,-1.1,0);
	glBegin(GL_QUADS);								
		glTexCoord2f(0.0f,0.0f); glVertex2f(-0.5f, -0.5f);		 
		glTexCoord2f(1.0f,0.0f); glVertex2f(0.5f, -0.5f);
		glTexCoord2f(1.0f,1.0f); glVertex2f(0.5f, 0.5f);			
		glTexCoord2f(0.0f,1.0f); glVertex2f(-0.5f,0.5f);		
	glEnd();	
    glPopMatrix();			
    
}

/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;     
    case '1':
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP );	
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP ); 
         break;  
    case '2':
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT );	
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT ); 
         break;           
    case '3':
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_MIRRORED_REPEAT_ARB );	
            glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_MIRRORED_REPEAT_ARB ); 
         break;                              
    default:     
      break;
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"OpenGL Texture Addressing");
     
      texID = loadJpegAs2DTexture("textures/five.jpg");
      
        glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP );	
        glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP ); 
     
      glutMainLoop();
}

