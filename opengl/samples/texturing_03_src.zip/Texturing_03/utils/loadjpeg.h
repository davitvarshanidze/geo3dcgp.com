#ifndef __LOADJPEG_H__
#define __LOADJPEG_H__

unsigned char *LoadJPEG(char*,int*,int*);

#endif /* __LOADJPEG_H__ */
