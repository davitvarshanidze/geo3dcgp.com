#ifndef __GL_UTILS_H__
#define __GL_UTILS_H__

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <GL/freeglut.h>
#include <GL/glext.h>

#include "loadjpeg.h"
 
typedef struct _ProgramState {
      
      int      winWidth; 
      int      winHeight;
} programState;

programState ps;

float *Load3DS(char *name,int *num_vertex);

void renderGraphics( void );  
void base_display( void );
void reshape( int w, int h );
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle );
void keyboard( unsigned char key, int x, int y );  
void selectTexture(int texID);
void enableAutoTexturing(unsigned int mode, GLfloat* plane);
void drawAxis(int size);
void drawtextAt(float x, float y, float z, void *font,char *string);
void init(void);
GLuint  loadJpegAs2DTexture(char *texturePath);

// create a matrix to project vertices onto a specific plane
void SetShadowMatrix(GLfloat destMat[16], const GLfloat lightPos[4], const GLfloat plane[4])
{
  GLfloat dot;

  // dot product of plane and light position
  dot = plane[0] * lightPos[0] + plane[1] * lightPos[1] + plane[2] * lightPos[2] + plane[3] * lightPos[3];

  // first column
  destMat[0] = dot - lightPos[0] * plane[0];
  destMat[4] = 0.0f - lightPos[0] * plane[1];
  destMat[8] = 0.0f - lightPos[0] * plane[2];
  destMat[12] = 0.0f - lightPos[0] * plane[3];

  // second column
  destMat[1] = 0.0f - lightPos[1] * plane[0];
  destMat[5] = dot - lightPos[1] * plane[1];
  destMat[9] = 0.0f - lightPos[1] * plane[2];
  destMat[13] = 0.0f - lightPos[1] * plane[3];

  // third column
  destMat[2] = 0.0f - lightPos[2] * plane[0];
  destMat[6] = 0.0f - lightPos[2] * plane[1];
  destMat[10] = dot - lightPos[2] * plane[2];
  destMat[14] = 0.0f - lightPos[2] * plane[3];

  // fourth column
  destMat[3] = 0.0f - lightPos[3] * plane[0];
  destMat[7] = 0.0f - lightPos[3] * plane[1];
  destMat[11] = 0.0f - lightPos[3] * plane[2];
  destMat[15] = dot - lightPos[3] * plane[3];
}


void renderBitmapString(float x, float y, float z, void *font,char *string) {
 
  
  char *c;
  glRasterPos3f(x, y, z);
//  glTranslatef(0,0,z);
 
  for (c=string; *c != '\0'; c++) {
    glutBitmapCharacter(font, *c);
  }  
  
}


void resetPerspectiveProjection() {
     
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void setOrthographicProjection() {

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, ps.winWidth, 0, ps.winHeight/2);
	glScalef(1, -1, 1);
	glTranslatef(0, -ps.winHeight/2, 0);
	glMatrixMode(GL_MODELVIEW);
}

void drawtextAt(float x, float y, float z, void *font,char *string) {

	setOrthographicProjection();
	glPushMatrix();
	glLoadIdentity();
	
	renderBitmapString( x, y, z ,font,string); 
	
	glPopMatrix();
	resetPerspectiveProjection();   
    glColor3f(1,1,1); 
}

/**
void drawAxis()
*/
void drawAxis(int size) {

    
    glLineWidth(3); 
	glBegin(GL_LINES);	 	
	
    	glColor3f(1,0,0);
    	glVertex3f(-size,0.0f,0.0f);
    	glVertex3f(size,0.0f,0.0f);
    	    
    	glColor3f(0,1,0);
    	glVertex3f(0.0f,-size,0.0f);
    	glVertex3f(0.0f,size,0.0f);
    	    
    	glColor3f(0,0,1);
    	glVertex3f(0.0f,0.0f,-size);
    	glVertex3f(0.0f,0.0f,size);
            	        
	glEnd();
	
   	glPushMatrix();
         glColor3f(1,0,0);
    	 glTranslatef(size,0,0);
         glRotatef(90,0,1,0);
    	 glutSolidCone(size/20.0f, size/8.0f, 20, 20 );
   	glPopMatrix();

   	glPushMatrix();
         glColor3f(0,1,0);
    	 glTranslatef(0,size,0);
         glRotatef(-90,1,0,0);
    	 glutSolidCone(size/20.0f, size/8.0f, 20, 20 );
   	glPopMatrix();

   	glPushMatrix();
         glColor3f(0,0,1);
    	 glTranslatef(0,0,size);
         glRotatef(90,0,0,1);
    	 glutSolidCone(size/20.0f, size/8.0f, 20, 20 );
   	glPopMatrix();

    glDisable(GL_LIGHTING);
    glColor3f(0,0,0);
    renderBitmapString(size+size/5.0f,0,0, GLUT_BITMAP_TIMES_ROMAN_24, "X");
    renderBitmapString(0,size+size/5.0f,0,  GLUT_BITMAP_TIMES_ROMAN_24, "Y");
    renderBitmapString(0,0,size+size/5.0f, GLUT_BITMAP_TIMES_ROMAN_24, "Z");
    
    glColor3f(1,1,1);
    glLineWidth(0.5);  
 }

void disableAutoTexturing() {
     
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);          
}


/**
void enableAutoTexturing(unsigned int mode, GLfloat* plane=0)
**/
void enableAutoTexturing(unsigned int mode, GLfloat* plane=0) {
     
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);     

  glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, mode);
  glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, mode);       
  
  if ( mode != GL_SPHERE_MAP ) {
       glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, mode);
       glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, mode);        
      if (plane!=0) {
    
        glTexGenfv(GL_S, GL_OBJECT_PLANE, plane);
        glTexGenfv(GL_T, GL_OBJECT_PLANE, plane);                
      }
  }
}

/**
void selectTexture(int texID)
**/
void selectTexture(int texID) {
     
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);   
}

/**
GLuint  loadJpegAs2DTexture(char *texturePath)
**/
GLuint  loadJpegAs2DTexture(char *texturePath) {

    int				width,height;
    unsigned char	*data;
    GLuint          texID = 0;
    
    glGenTextures(1, &texID);
   
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR );	
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR ); 
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT );	
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT ); 
        
    glBindTexture(GL_TEXTURE_2D, texID);
    
    if((data = LoadJPEG(texturePath,&width,&height))) {
    
    	gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);

    	free(data);	 
    }
   
   return texID;
}

/**
 GLuint load3dsAsList(char* filepath)
**/
GLuint load3dsAsList(char* filepath) {
       
    float  *model;       
    GLuint  modelList;
    int     num_face;          
      
    model = Load3DS(filepath,&num_face);
	modelList = glGenLists(1);

	glNewList(modelList,GL_COMPILE);
	glBegin(GL_TRIANGLES);
	for(int i = 0; i < num_face; i++) {
 	 glNormal3fv((float*)&model[i << 3] + 3);
	 glVertex3fv((float*)&model[i << 3]);
	}
	glEnd();
	glEndList();
	free(model);       
    
    return  modelList;      
}


/**
void reshape( int w, int h )
**/
void reshape( int width, int height )
{
  ps.winWidth  = width;
  ps.winHeight = height;
  
	if (height == 0)					
	{
		height = 1;					
	}

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT);

	glViewport(0, 0, width, height);		
	glMatrixMode(GL_PROJECTION);			
	glLoadIdentity();						

	gluPerspective(60.0f,(GLfloat)width/(GLfloat)height,0.1f,100000.0f);

	glMatrixMode(GL_MODELVIEW);				
	glLoadIdentity();	   					
}

/**
void base_display( void )
**/
void base_display( void ) {
  
  static int cTime = 0; 

  SleepEx(2,FALSE);

  if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/60  ) return;

  cTime = glutGet(GLUT_ELAPSED_TIME);
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  glLoadIdentity();									

  renderGraphics();   
  
  glutSwapBuffers();       
}

/**
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle )
**/
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle )  {
	
  glutInit( &argc, argv ); 
  glutInitDisplayMode( displayMode ); 
  glutInitWindowSize( width, height ); 
  glutCreateWindow( windowTitle ); 
  glClearColor(0.5, 0.6, 0.8, 0.0);
    
    glShadeModel(GL_SMOOTH);							      
    glEnable(GL_DEPTH_TEST);
    glClearDepth(1.0f);								      						
    glDepthFunc(GL_LEQUAL);							

  glutDisplayFunc( base_display );  
  glutIdleFunc( base_display );  
  glutReshapeFunc( reshape );
  glutKeyboardFunc( keyboard ); 
}


#endif /* __GL_UTILS_H__ */
