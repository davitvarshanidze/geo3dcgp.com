#include "utils/glUtils.h"

#undef PI               
#define PI 3.141592657
#define SCALE_FACTOR 300000
#define STAR_NUM     500
#define MAXPOS       32000


typedef struct _star {
   
   float x;
   float y;
   float z;
   int   size;
} star;

typedef struct _celestialBody {
  
  char*       name;
  GLuint      texID; 
  float       spin;
  float       orbit;
  float       diameter;
  float       mass;
  int         year;       
  GLubyte     color[4];
  
} celestialBody;

celestialBody solSys[9]; 
star          stars[STAR_NUM];  

// Lighting values
GLfloat ambientLight0[] = { 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat ambientLight1[] = { 0.1f, 0.1f, 0.1f, 1.0f };
GLfloat diffuseLight[]  = { 0.7f, 0.7f, 0.7f, 1.0f };
GLfloat specular[]      = { 1.0f, 1.0f, 1.0f, 1.0f };

GLfloat specref[]       = { 1.0f, 1.0f, 1.0f, 1.0f };

GLfloat	lightPos[]      = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat emissionSun[]   = { 0.9f, 0.0f, 0.0f, 0.0f};
GLfloat nullv[]         = { 0.0f, 0.0f, 0.0f, 1.0f};

float g_fSpeedmodifier = 1.0f;

GLuint sunTexID;
GLuint skyBoxTex[6];
GLuint satrTexID;

GLuint starsList;

bool enableLightning = false;
bool enableTexturing = false;
bool pause           = false;
bool tracking        = false;
bool demoMode        = false;

float camX; 
float camY;
float camZ;

float camLookX; 
float camLookY;
float camLookZ;

int glookAt = -1;

GLUquadricObj* pSphere = gluNewQuadric();
	
void setupLighting(void);
void drawSaturnRing(float radius);
void drawOrbit(GLfloat rad, GLfloat inc, char* Str, float fangle=90);

void CreateSkyBox(float x, float y, float z, float width, float height, float length, GLuint texture[6])
{
    	x = x - width  / 2;
    	y = y - height / 2;
    	z = z - length / 2;

        if (texture[1])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[1]);
	
	    glBegin(GL_QUADS);		
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y, z);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height, z); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x,	y + height, z);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x,	y, z);
		
	    glEnd();
        }

        if (texture[0])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[0]);

	    glBegin(GL_QUADS);	
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x,	y, z + length);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x,	y + height, z + length);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z + length); 
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y, z + length);
	    glEnd();
        }

        if (texture[5])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[5]);

	    glBegin(GL_QUADS);		
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x,	y, z);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x,	y, z + length);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y, z + length); 
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y, z);
	    glEnd();
        }

        if (texture[4])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[4]);
	
	    glBegin(GL_QUADS);		
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y + height, z + length); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x,	y + height, z + length);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x,	y + height, z);
	    glEnd();
        }

        if (texture[2])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[2]);
	
	    glBegin(GL_QUADS);		
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x,	y + height, z);	
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x,	y + height, z + length); 
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x,	y, z + length);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x,	y, z);		
	    glEnd();
        }

        if (texture[3])
        {
	    glBindTexture(GL_TEXTURE_2D, texture[3]);

	    glBegin(GL_QUADS);		
		glTexCoord2f(0.0f, 0.0f); glVertex3f(x + width, y, z);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(x + width, y, z + length);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(x + width, y + height, z + length); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(x + width, y + height, z);
	    glEnd();
        }
}

void setupLighting(void)
{
if (enableLightning) {
                     
	glEnable(GL_LIGHTING);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

	glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLight1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular);

	glEnable(GL_COLOR_MATERIAL);
	
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
 }
  else  {
   	glDisable(GL_LIGHTING);
  }
}



void init() {
   
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glClearColor(0.0, 0.0, 0.0, 0.0);
	
	camX = 0; 
    camY = 8000;
    camZ = 26000;

    camLookX    = 0; 
    camLookY    = 0;
    camLookZ    = 0;

	glShadeModel(GL_SMOOTH);

    satrTexID    = loadJpegAs2DTexture("textures/saturnringcolor.jpg");
    sunTexID     = loadJpegAs2DTexture("textures/sunmap.jpg");	
    skyBoxTex[0] = loadJpegAs2DTexture("textures/space.jpg");	
    skyBoxTex[1] = skyBoxTex[2] = skyBoxTex[3] = skyBoxTex[4] = skyBoxTex[5] = skyBoxTex[0];

	srand((unsigned int) glutGet(GLUT_ELAPSED_TIME));
	
    gluQuadricNormals(pSphere, GLU_SMOOTH);
    gluQuadricTexture(pSphere, GL_TRUE);
    
    solSys[0].name      = "Mercury";
    solSys[0].texID     = loadJpegAs2DTexture("textures/mercurymap.jpg");
    solSys[0].diameter  = 4880*200/SCALE_FACTOR;
    solSys[0].orbit     = 57910000/SCALE_FACTOR; 
    solSys[0].mass      = 3.30e-23;  
    solSys[0].spin      = 10;
    solSys[0].year      = 243;
    solSys[0].color[0]  = 20;
    solSys[0].color[1]  = 20;
    solSys[0].color[2]  = 20;
    solSys[0].color[3]  = 1;
    
    solSys[1].name      = "Venus";
    solSys[1].texID     = loadJpegAs2DTexture("textures/venusmap.jpg");
    solSys[1].diameter  = 12103*200/SCALE_FACTOR;
    solSys[1].orbit     = 108200000/SCALE_FACTOR; 
    solSys[1].mass      = 4.869e-24 ;
    solSys[1].year      = 365/243;  
    solSys[1].spin      = 20;
    solSys[1].color[0]  = 249;
    solSys[1].color[1]  = 234;
    solSys[1].color[2]  = 103;
    solSys[1].color[3]  = 1;    
    
    solSys[2].name      = "Earth";
    solSys[2].texID     = loadJpegAs2DTexture("textures/earthmap1k.jpg");
    solSys[2].diameter  = 12756*200/SCALE_FACTOR;
    solSys[2].orbit     = 149600000/SCALE_FACTOR; 
    solSys[2].mass      = 5.972e-24;  
    solSys[2].spin      = 30;
    solSys[2].year      = 365;
    solSys[2].color[0]  = 30;
    solSys[2].color[1]  = 80;
    solSys[2].color[2]  = 255;
    solSys[2].color[3]  = 1;    

    solSys[3].name      = "Mars";
    solSys[3].texID     = loadJpegAs2DTexture("textures/marsmap1k.jpg");
    solSys[3].diameter  = 6794*200/SCALE_FACTOR;
    solSys[3].orbit     = 227940000/SCALE_FACTOR; 
    solSys[3].mass      = 6.4219e-23;  
    solSys[3].year      = 100;
    solSys[3].spin      = 30;
    solSys[3].color[0]  = 255;
    solSys[3].color[1]  = 20;
    solSys[3].color[2]  = 35;
    solSys[3].color[3]  = 1; 
    
    solSys[4].name      = "Jupiter";
    solSys[4].texID     = loadJpegAs2DTexture("textures/jupitermap.jpg");
    solSys[4].diameter  = 142984*200/SCALE_FACTOR;
    solSys[4].orbit     = 778330000/SCALE_FACTOR; 
    solSys[4].mass      = 1.900e-27;  
    solSys[4].year      = 100;
    solSys[4].spin      = 40;
    solSys[4].color[0]  = 30;
    solSys[4].color[1]  = 22;
    solSys[4].color[2]  = 5;
    solSys[4].color[3]  = 1;   
    
    solSys[5].name      = "Saturn";
    solSys[5].texID     = loadJpegAs2DTexture("textures/saturnmap.jpg");
    solSys[5].diameter  = 120536*200/SCALE_FACTOR;
    solSys[5].orbit     = 1429400000/SCALE_FACTOR; 
    solSys[5].mass      = 5.68e-26;  
    solSys[5].year      = 100;
    solSys[5].spin      = 50;
    solSys[5].color[0]  = 91;
    solSys[5].color[1]  = 102;
    solSys[5].color[2]  = 92;
    solSys[5].color[3]  = 1;   

    solSys[6].name      = "Uranus";
    solSys[6].texID     = loadJpegAs2DTexture("textures/uranusmap.jpg");
    solSys[6].diameter  = 51118*200/SCALE_FACTOR;
    solSys[6].orbit     = 2870990000.0/SCALE_FACTOR; 
    solSys[6].mass      = 8.683e-25;  
    solSys[6].year      = 100;
    solSys[6].spin      = 60;
    solSys[6].color[0]  = 34;
    solSys[6].color[1]  = 45;
    solSys[6].color[2]  = 255;
    solSys[6].color[3]  = 1;       
    
    solSys[7].name      = "Neptune";
    solSys[7].texID     = loadJpegAs2DTexture("textures/neptunemap.jpg");
    solSys[7].diameter  = 49532*200/SCALE_FACTOR;
    solSys[7].orbit     = 4504000000.0/SCALE_FACTOR; 
    solSys[7].mass      = 1.0247e-26;  
    solSys[7].year      = 100;
    solSys[7].spin      = 70;
    solSys[7].color[0]  = 64;
    solSys[7].color[1]  = 65;
    solSys[7].color[2]  = 255;
    solSys[7].color[3]  = 1;           
    
    for(int i=0;i<STAR_NUM;i++) {
        stars[i].x     = (float) (rand() % MAXPOS - MAXPOS/2)*2;
        stars[i].y     = (float) (rand() % MAXPOS - MAXPOS/2)*2;
        stars[i].z     = (float) (rand() % MAXPOS - MAXPOS/2)*2;
        stars[i].size  = (int) (rand() % 3);
    }

    starsList  = glGenLists (1);

    glNewList (starsList, GL_COMPILE);
    
       for(int i=0;i<STAR_NUM;i++) { 
               
         glPointSize(stars[i].size);      
         
         int fadeFact = abs((int)stars[i].z)%255;
         
         glColor3ub(fadeFact,fadeFact,fadeFact);
              
         glBegin(GL_POINTS);
          glVertex3f(stars[i].x,stars[i].y,stars[i].z);
         glEnd();
       }
   
   glEndList();    
}

void drawCelestialBody( int bID )  {
     
    GLfloat orbit = 1390000*200/SCALE_FACTOR + solSys[bID].orbit;  
    
    drawOrbit(orbit, 1, solSys[bID].name, solSys[bID].spin);
       
    glPushMatrix(); 
    {
        glRotatef( solSys[bID].spin, 0.0f, 1.0f, 0.0f ); 
        glTranslatef( 0.0f, 0.0f, orbit );   
        glRotatef( solSys[bID].spin*solSys[bID].year, 0.0f, 1.0f, 0.0f );  
        glRotatef( 90, 1.0f, 0.0f, 0.0f );
        
           if (enableTexturing) {
            glColor4f( 1, 1, 1, 1.0f );                     
            selectTexture(solSys[bID].texID);
           }
           else
            glColor4ubv( solSys[bID].color ); 
        
            gluSphere(pSphere, solSys[bID].diameter, 40, 40);
            
            if (enableTexturing)
            glBindTexture(GL_TEXTURE_2D, 0);
                                
        if (!strcmp(solSys[bID].name,"Saturn")) 
             drawSaturnRing(solSys[bID].diameter);
    }
    glPopMatrix();      
    
    
    if (bID == 2) {
     
     glPushMatrix();       
     
        glRotatef( solSys[bID].spin, 0.0f, 1.0f, 0.0f ); 
        glTranslatef( 0.0f, 0.0f, orbit );   
     
        glRotatef( solSys[bID].spin*100, 1.0f, 1.0f, 0.0f );  
        glTranslatef( 0.0f, 0.0f, -15.0f );          

        glColor4f( 1.0f, 1.0f, 1.0f, 1.0f );
        glutSolidSphere( 1.2f, 20, 20 );                    
        
       glPopMatrix(); 
    }
    
}

void lookAtPlanet( int bID ) {
    
    GLfloat orbit = 1390000*200/SCALE_FACTOR + solSys[bID].orbit;  

    static float cCamX = 0;
    static float cCamY = 0;
    static float cCamZ = 0;  

    float dist = sqrt(
         (cCamX - camX)*(cCamX - camX) + 
         (cCamY - camY)*(cCamY - camY) +
         (cCamZ - camZ)*(cCamZ - camZ)
         );

    if ( dist < 3 )
       tracking = false; 

  
     camLookX = orbit*sin((solSys[bID].spin)*3.1415926535/180);
     camLookZ = orbit*cos((solSys[bID].spin)*3.1415926535/180);
    
        if (bID<4) {
         cCamX = camLookX + solSys[bID].diameter*4 + 1/solSys[bID].orbit * 2000;          
         cCamY = solSys[bID].diameter*2 + solSys[bID].orbit * 0.02;
         cCamZ = camLookZ + solSys[bID].diameter*4 + 1/solSys[bID].orbit * 2000;
        } 
        else {
         cCamX = camLookX + solSys[bID].diameter*10;
         cCamY = solSys[bID].diameter*2 + solSys[bID].orbit * 0.02;
         cCamZ = camLookZ + solSys[bID].diameter*10;
        } 
    
    if (tracking) {
        camX += (cCamX - camX)/30;
        camY += (cCamY - camY)/30;
        camZ += (cCamZ - camZ)/30;
    }
    
    glPushAttrib(GL_LIGHTING_BIT); 
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glColor4f(0.0, 1.0, 0.0, 1.0);    
        
        float x = orbit*sin((solSys[bID].spin)*3.1415926535/180);
        float z = orbit*cos((solSys[bID].spin)*3.1415926535/180);
         
        char msg[1024];              
        
        int    sy   = 16;
        float  koef = 1;
        
        if (bID>=4) {
          sy   = 100;          
          koef = 30;
        }

        if (bID==0) {
          sy   = 1;          
          koef = 0.8;
        }
        
        renderBitmapString(camLookX+solSys[bID].diameter,sy,camLookZ+solSys[bID].diameter, GLUT_BITMAP_HELVETICA_18, solSys[bID].name);	
        sprintf(msg, "diameter: %f km", solSys[bID].diameter);
        renderBitmapString(camLookX+solSys[bID].diameter,sy-1*koef,camLookZ+solSys[bID].diameter, GLUT_BITMAP_HELVETICA_12, msg);
        sprintf(msg, "mass: %e ", solSys[bID].mass);
        renderBitmapString(camLookX+solSys[bID].diameter,sy-2*koef,camLookZ+solSys[bID].diameter, GLUT_BITMAP_HELVETICA_12, msg);
        sprintf(msg, "%f km from Sun", solSys[bID].orbit);
        renderBitmapString(camLookX+solSys[bID].diameter,sy-3*koef,camLookZ+solSys[bID].diameter, GLUT_BITMAP_HELVETICA_12, msg);
        glEnable(GL_DEPTH_TEST);
    }
    glPopAttrib();

}

void drawOrbit(GLfloat rad, GLfloat inc, char* Str, float fangle) {
   
	glPushMatrix();

	GLfloat y = 0.0;
	glColor3f(0.5, 0.5, 0.5);
	
    GLfloat x;
	GLfloat z;
	
	GLfloat emissionPath[]   = { 0.5f, 0.5f, 0.5f, 0.0f};

    glMaterialfv(GL_FRONT, GL_EMISSION, emissionPath); 

	glBegin(GL_LINES);
	for(GLfloat angle = 0; angle <= 360; angle+=0.5) {
                
		x = rad*sin((angle)*3.1415926535/180);
		z = rad*cos((angle)*3.1415926535/180);

		glVertex3f(x, y, z);
	}
	
	glEnd();
	
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_EMISSION, nullv);    	
}

void drawSun() {

    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT1, GL_POSITION, lightPos); 
    
    glPushMatrix();     

    glColor4f(1.0, 1.0, 1.0, 1.0);    
    renderBitmapString(3,1500,0, GLUT_BITMAP_HELVETICA_18, "SUN");

    glColor4f(1.0, 0.8, 0.0, 1.0);    
     
    if (enableLightning) {
        glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
        glMaterialfv(GL_FRONT, GL_EMISSION, emissionSun); 
        glMateriali(GL_FRONT, GL_SHININESS, 3);
    }
    
    if (enableTexturing) 
    selectTexture(sunTexID);

    gluSphere(pSphere, 1000.0, 60, 60);
    
    if (enableTexturing)
    glBindTexture(GL_TEXTURE_2D, 0);
    
    glPopMatrix();          
    
    if (enableLightning) {
     glDisable(GL_LIGHT0);
     glEnable(GL_LIGHT1); 
    }
}

void drawSaturnRing(float radius) {

 static GLuint ringList = 0;      

    glDisable(GL_CULL_FACE);
    if (enableTexturing) 
           selectTexture(satrTexID);

  if (ringList == 0) {
               
    ringList  = glGenLists (1);

    glNewList (ringList, GL_COMPILE);
     
         glColor4f( 1, 1, 1, 1.0f );                                
         glRotatef( 90, 1.0f, 0.0f, 0.0f );   
            
         glBegin(GL_QUAD_STRIP); 
            for(GLfloat angle = 0; angle <= 360; angle+=5) {
                    
             float sinx =  sin((angle)*3.1415926535/180);
             float cosx =  cos((angle)*3.1415926535/180);
    
    		 float x1 = (radius-180)*sinx;
    		 float z1 = (radius-180)*cosx;
                  
    		 float x2 = (radius-260)*sinx;
    		 float z2 = (radius-260)*cosx;
    
           if ( ((int)angle) % 10)
    		 glTexCoord2f(1, 1); 
    	    else	
             glTexCoord2f(1, 0);  
             
             glNormal3f(0, -1, 0); 
             glVertex3f(x2, 0, z2);
             
           if ( ((int)angle) % 10)
    		 glTexCoord2f(0, 1); 
    	    else	
             glTexCoord2f(0, 0);  
             
    		 
             glNormal3f(0, -1, 0); 
             glVertex3f(x1, 0, z1);
        	}
    	glEnd(); 
     glEndList();           	
   }
   
    glCallList(ringList);
   
    glEnable(GL_CULL_FACE);   
         
    if (enableTexturing)
      glBindTexture(GL_TEXTURE_2D, 0);         
}

void demo() {

   static long demoTime = 0;
   static long cMode    = 0;
        
   if ( glutGet(GLUT_ELAPSED_TIME) - demoTime > 7000  ) {

        if (cMode==0) {        
          glPolygonMode(GL_FRONT, GL_LINE);
          enableLightning = false;
          enableTexturing = false;
          setupLighting();    
        }
        
        if (cMode==1) {
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = false;
          enableTexturing = false;
          setupLighting();        
        }
        
        if (cMode==2) {
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = true;
          enableTexturing = false;
          setupLighting();
        }

        if (cMode==3) {
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = true;
          enableTexturing = true;
          setupLighting();
          cMode = rand() % 36;
        }
        
        demoTime = glutGet(GLUT_ELAPSED_TIME);
        
        glookAt++;
        if (glookAt==8)
         glookAt=0;
         
        tracking = true;        
        cMode++;
   }     
}


void renderGraphics( void )  {
     
    gluLookAt( camX, camY, camZ,
               camLookX, camLookY, camLookZ,   
               0.0, 1.0, 0.0 ); 
 
  if (demoMode) demo();

   glPushAttrib(GL_LIGHTING_BIT); 
   glDisable(GL_LIGHTING);
   
      
    if (enableTexturing)  {  
                                     
        glColor4f(0.8,0.8,0.8, 0.4);                          

        CreateSkyBox( 0,0,-10000,
                      100000, 100000, 100000,
                      skyBoxTex 
                     );
                     
        glBindTexture(GL_TEXTURE_2D, 0);        
    }
             
   glCallList (starsList);
      
   glEnable(GL_LIGHTING);
   glPopAttrib(); 
      
   drawSun();

   glMaterialfv(GL_FRONT, GL_SPECULAR, nullv);
   glMaterialfv(GL_FRONT, GL_EMISSION, nullv);    
   
   if (!pause) {
    
    solSys[0].spin -= 0.03f;
    solSys[1].spin -= 0.05f;
    solSys[2].spin -= 0.02f;
    solSys[3].spin -= 0.03f;
    solSys[4].spin -= 0.04f;
    solSys[5].spin -= 0.07f;
    solSys[6].spin -= 0.08f;
    solSys[7].spin -= 0.03f;          
   }
   
   for (int i=0;i<8;i++)
   drawCelestialBody(i); 
   
   if (glookAt != -1)
    lookAtPlanet(glookAt);      
}

/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit (0);
      break;   
     
    case '`':
         glPolygonMode(GL_FRONT, GL_LINE);
          enableLightning = false;
          enableTexturing = false;
          setupLighting();    
    break;
    case '1':
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = false;
          enableTexturing = false;
          setupLighting();        
    break;       
    case '2':            
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = true;
          enableTexturing = false;
          setupLighting();
    break;
    case '3':            
          glPolygonMode(GL_FRONT, GL_FILL);
          enableLightning = true;
          enableTexturing = true;
          setupLighting();
    break;
    
    
    case ' ':
         pause    = !pause;
         tracking = false;
    break;           
    
    case 'd':
         demoMode = !demoMode;
         break;
    case 'z':
        camX = 0; 
        camY = 8000;
        camZ = 26000;
        
        camLookX    = 0; 
        camLookY    = 0;
        camLookZ    = 0;   
        glookAt      = -1;
    break;   

    case 'c':
         if (glookAt<7)
          glookAt++;
         else
          glookAt = 0;
          tracking = true;
    break;   

    case 'x':
         if (glookAt>1)
          glookAt--;
         else
          glookAt = 0; 
    break;       
    
    default:     
      break;
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_ACCUM,"Solar System");
     
      init();
      glPolygonMode(GL_FRONT, GL_LINE);
      
      glutMainLoop();
}

