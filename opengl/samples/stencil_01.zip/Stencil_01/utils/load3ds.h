/*  load 3ds file
 *
 *      written by Alexander Zaprjagaev
 *      frustum@public.tsu.ru
 *      2:5005/93.15@FidoNet
 */
#ifndef __LOAD3DS_H__
#define __LOAD3DS_H__

// total 8 floats
// 1,2,3 - vertex
// 3,4,5 - normal
// 6,7 - texture coordinate

float *Load3DS(char *name,int *num_vertex);

#endif /* __LOAD3DS_H__ */
