#include "utils/glUtils.h"

GLuint modelList,texture;

void renderGraphics( void )  {
     
    gluLookAt(0,150,1,0,0,0,0,1,0);
   
    static float rotA = 0;
    
    rotA++ ;
    
    glRotatef(rotA, 0,1,0); 	    
    
	glEnable(GL_TEXTURE_2D);	
    glEnable(GL_TEXTURE_GEN_S);	
    glEnable(GL_TEXTURE_GEN_T);
    
	glColor3f(1,1,1);
    glPolygonMode(GL_FRONT,GL_FILL); 
    glCallList(modelList);
	glDisable(GL_TEXTURE_2D);	
    glDisable(GL_TEXTURE_GEN_S);	
    glDisable(GL_TEXTURE_GEN_T);
    
	glLineWidth(1.0);
	glEnable(GL_STENCIL_TEST);
	glColorMask(0,0,0,0);
	glStencilFunc (GL_ALWAYS, 1, 1);
	glStencilOp (GL_KEEP, GL_KEEP, GL_REPLACE);
	glDisable(GL_DEPTH_TEST);
	glPolygonMode(GL_FRONT,GL_FILL); 
	
    glCallList(modelList);
	glEnable(GL_DEPTH_TEST);	
	glStencilFunc (GL_NOTEQUAL, 1, 1);
	glStencilOp (GL_KEEP, GL_KEEP, GL_KEEP);
	glColorMask(1,1,1,1); 
	glLineWidth(5.0);
	glColor3f(0,1,0);
	glPolygonMode(GL_FRONT,GL_LINE); glCallList(modelList);
	glDisable(GL_STENCIL_TEST);         
}


void programInit(void) {

	float			*model;
	unsigned char	*data;
	int				width,height,num_face;

	glClearDepth(1);
	glClearColor(0,0,0,0);
	glClearStencil(0);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glEnable(GL_LIGHT0);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

    texture = loadJpegAs2DTexture("textures/base.jpg");
    enableAutoTexturing(GL_SPHERE_MAP);
	
	model = Load3DS("mesh/pyramob.3ds",&num_face);
	modelList = glGenLists(1);

	glNewList(modelList,GL_COMPILE);
	glBegin(GL_TRIANGLES);
	for(int i = 0; i < num_face; i++) {
		glNormal3fv((float*)&model[i << 3] + 3);
		glVertex3fv((float*)&model[i << 3]);
		}
	glEnd();
	glEndList();
	free(model);

	float light[4] = {0,10,10,0};
	glLightfv(GL_LIGHT0,GL_POSITION,light);	
}



int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE | GLUT_STENCIL,"OpenGL Stencil buffer");              
      
      programInit();      
      
      glutMainLoop();
}

