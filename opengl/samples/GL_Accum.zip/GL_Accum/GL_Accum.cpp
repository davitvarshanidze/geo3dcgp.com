#include "utils/glUtils.h"

void DrawSpheres(GLfloat angle);

void DrawCone()
{
  glPushMatrix();
  glTranslatef(0.0, 3.0, 1.0);
  glRotatef(m_angle, 1.0f, 0.1f, 0.0f);
  glRotatef(90, 0.0f, 1.0f, 0.0f);
  gluCylinder(m_pObj, 0, 1.0, 2.0, 32, 8);
  glPopMatrix();
}

void DrawFloor()
{
  glColor3f(1.0, 1.0, 1.0);
  glNormal3f(0.0, 1.0, 0.0);
  glBegin(GL_QUADS);
    glVertex3f(-4.0, 0.0, 4.0);
    glVertex3f(4.0, 0.0, 4.0);
    glVertex3f(4.0, 0.0, -4.0);
    glVertex3f(-4.0, 0.0, -4.0);
  glEnd();
}

void DrawSpheres(GLfloat angle)
{
  glPushMatrix();
    glRotatef(angle, 0.0f, 0.0f, -1.0f);

    glPushMatrix();
      glColor3f(0.0f, 0.8f, 0.4f);
      glTranslatef(-2.5f, 0.0f, 0.0f);
      gluSphere(m_pObj, 1.5f, 32, 32);
    glPopMatrix();

    glColor3f(1.0f, 0.8f, 0.1f);
    glTranslatef(2.5f, 0.0f, 0.0f);
    gluSphere(m_pObj, 1.5f, 32, 32);
  glPopMatrix();
}

void RenderMotionBlur()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();
  gluLookAt(0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

  GLfloat angle = m_angle;
  for (int i = 0; i < SPHERE_NUM_SAMPLES; ++i)
  {
    DrawSpheres(angle);
    angle -= SPHERE_BLUR_ARC/SPHERE_NUM_SAMPLES;

    if (i == 0)
      glAccum(GL_LOAD, 1.0f/SPHERE_NUM_SAMPLES);
    else
      glAccum(GL_ACCUM, 1.0f/SPHERE_NUM_SAMPLES);
  }
  glAccum(GL_RETURN, 1.0);
}


void RenderSoftShadow()
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT);
  glLoadIdentity();
  gluLookAt(5.0, 8.0, 10.0, 0.0, 2.0, 0.0, 0.0, 1.0, 0.0);

  for (int i = 0; i < SHADOW_NUM_SAMPLES; ++i)
  {
    SetShadowMatrix(m_shadowMatrix, LIGHT_POS[i], FLOOR_PLANE);
    // draw the shadow
    glPushMatrix();
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glEnable(GL_LIGHTING);
      glLightfv(GL_LIGHT0, GL_POSITION, LIGHT_POS[0]);
      DrawFloor();
      
      glDisable(GL_LIGHTING);
      glDisable(GL_DEPTH_TEST);

      glColor4f(0.0, 0.0, 0.0, 1.0f);

      // project the cone through the shadow matrix
      glMultMatrixf(m_shadowMatrix);
      DrawCone();

      glEnable(GL_DEPTH_TEST);
    glPopMatrix();
    glAccum(GL_ACCUM, 1.0f/SHADOW_NUM_SAMPLES);
  }

  glAccum(GL_RETURN, 1.0);
  
  glLightfv(GL_LIGHT0, GL_POSITION, LIGHT_POS[0]);

  // draw the cone normally
  glEnable(GL_LIGHTING);
  glColor3f(0.1f, 0.2f, 0.8f);
  DrawCone();
  glDisable(GL_LIGHTING);
}

void renderGraphics(void) {

  gluLookAt(0.0, 0.6, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 ); 

  m_angle += 0.01 * DEG_PER_S;

  if (m_angle > 360.0)
    m_angle = 0.0;
          
  switch(m_state)
  {
  case MOTION_BLUR:
    RenderMotionBlur();
    break;
  case SOFT_SHADOW:
    RenderSoftShadow();
    break;
  default:
    break;
  }
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	  case 27:
		  exit(0);
		  break;
		
      case 'm':
       m_state = MOTION_BLUR;
       break;
      case 's': 
       m_state = SOFT_SHADOW;
       break;         
      }   
}


int main(int argc, char** argv) {
             
    initOpenGL(argc, argv, 800,600, 
    GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_ACCUM , "Accumulation buffer demo");
	
	init();					

	glutMainLoop();
		
	return 0;
}
