#include <GL/freeglut.h>
#include <math.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>

#define QUAD_NUM 10

#define RX		1.5
#define RY		1.5
#define RZ		1.5
#define VX0		-0.005
#define VY0		-0.005
#define VZ0		-0.05
#define SC0     0.1
#define Z0		(-QUAD_NUM*2)
#define X0		(-QUAD_NUM*2)
#define Y0		(-QUAD_NUM*2)
#define Z1		(QUAD_NUM*2)
#define X1		(QUAD_NUM*2)
#define Y1		(QUAD_NUM*2)

typedef struct _quad {
        
	float x, y, z;
	float velX, velY, velZ;
	float rotX, rotY, rotZ;
	bool  backway;
	} tQuad;

tQuad quads[QUAD_NUM*QUAD_NUM]; 
bool  boomMode = false;
bool  RBRender = true;

double PIXELS_PER_INCH = 50.0;

struct ProgramState
{
 int w;
 int h;
 double eye;
 double zscreen;
 double znear;
 double zfar;
 int    stereo;
 bool   mblur;
};

struct ProgramState ps;

void initQuad(tQuad &quad) {
          
	quad.rotX  = RX + ((float)rand()/32767)*(180);
	quad.rotY  = RY + ((float)rand()/32767)*(180);
	quad.rotZ  = RZ + ((float)rand()/32767)*(180);
	
    quad.velX  = VX0 + ((float)rand()/32767)*(0.01f);
	quad.velY  = VY0 + ((float)rand()/32767)*(0.01f);
	quad.velZ  = VZ0 + ((float)rand()/32767)*(0.1f);
	
	quad.backway = false;
}

void initBoom() {
     
     srand(glutGet(GLUT_ELAPSED_TIME));
     
    for(int y=0;y<QUAD_NUM;y++) 
     for(int x=0;x<QUAD_NUM;x++) {
                  
        quads[QUAD_NUM*x+y].x = x;
        quads[QUAD_NUM*x+y].y = y;
        quads[QUAD_NUM*x+y].z = 0;
            
        initQuad(quads[QUAD_NUM*x+y]);                    
     }
     
     boomMode = true;
}

void initLight0(void) {

 glDisable(GL_DITHER);
 glClearColor(0.0, 0.0, 0.0, 1.0);
 glShadeModel(GL_SMOOTH);
 glEnable(GL_DEPTH_TEST);
 glEnable(GL_NORMALIZE);
// glEnable(GL_CULL_FACE);

 glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);
 glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,1); 
     
 GLfloat   mat_ambient[]   = { 0.24, 0.22, 0.06, 1.0};
 GLfloat   mat_diffuse[]   = { 0.34, 0.31, 0.09, 1.0};
 GLfloat   mat_specular[]  = { 0.79, 0.72, 0.20, 1.0};
 GLfloat   mat_shininess[] = {83.2};
    
 GLfloat light_position[]  = {0.0,5.0,20.0,1.0};

 GLfloat light_ambient0[]  = {0.5,0.5,0.5,1.0};
 GLfloat light_diffuse0[]  = {1.0,1.0,1.0,1.0};
 GLfloat light_specular0[] = {1.0,1.0,1.0,1.0};

 glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
 glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
 glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
 glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

 glLightfv(GL_LIGHT0, GL_POSITION, light_position);
 glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient0);
 glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse0);
 glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular0);

 glEnable(GL_LIGHTING);     
}

void initLight1(void) {
      
 GLfloat light_position[]  = {0.0,5.0,20.0,1.0};

 GLfloat light_ambient1[]  = {0.0,0.0,1.0,1.0};
 GLfloat light_diffuse1[]  = {0.0,0.0,1.0,1.0};
 GLfloat light_specular1[] = {0.0,0.0,1.0,1.0};

 glLightfv(GL_LIGHT1, GL_POSITION, light_position);
 glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient1);
 glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse1);
 glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular1);
    
}	
	
void init(void) {

    initLight0();
    initLight1();
        
    glClear(GL_ACCUM_BUFFER_BIT);
    glAccum(GL_LOAD, 1);
    
     ps.eye     = 1.0;
     ps.zscreen = 70.0;
     ps.znear   = 2.0;
     ps.zfar    = 300.0;
     ps.stereo  = 1;
     ps.mblur   = false;     
}	


void renderStringAt(float x, float y,void* font, const char* string) {
	glRasterPos2f(x,y);
	char* p = (char*) string;
	while (*p != '\0') glutBitmapCharacter(font, *p++);
}

float getfps(void) {
	static float fps = 60;
	static int starttime,endtime,counter;
	if(counter == 10) {
		endtime = starttime;
		starttime = glutGet(GLUT_ELAPSED_TIME);
		fps = counter * 1000.0 / (float)(starttime - endtime);
		counter = 0;
		}
	counter++;
	return fps;
}	


void display(void) {

	glClear (GL_COLOR_BUFFER_BIT);

    static int cTime = 0; 
   
    SleepEx(1,FALSE);
    
    if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/80  ) return;
    
    cTime = glutGet(GLUT_ELAPSED_TIME);

    double xfactor=1.0, yfactor=1.0;

     if(ps.w < ps.h)
     {
      xfactor = 1.0;
      yfactor = ps.h/ps.w;
     }
     else if(ps.h < ps.w)
     {
      xfactor = ps.w/ps.h;
      yfactor = 1.0;
     }      	   

    static float  rotA   = 0;
    
    rotA += 0.5;      
       
    if (rotA>360)         
        rotA = 0;
        
    float Eye = 0.0;      
    
    for(int renPass=0;renPass<ps.stereo;renPass++) {         
            
     glEnable(GL_LIGHT0 + renPass);
     
     glClear(GL_DEPTH_BUFFER_BIT);
     
   if (ps.stereo==2) {
       if(renPass==0) {
        Eye = ps.eye;
        glColorMask(GL_TRUE,GL_FALSE,GL_FALSE,GL_TRUE);
       }
       else {
        Eye = -ps.eye;
        if (RBRender)
         glColorMask(GL_FALSE,GL_FALSE,GL_TRUE,GL_TRUE);
        else 
         glColorMask(GL_FALSE,GL_TRUE,GL_FALSE,GL_TRUE); 
       }
    }
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  glFrustum(
   (-(ps.w/(2.0*PIXELS_PER_INCH))+Eye) *(ps.znear/ps.zscreen)*xfactor,
   (ps.w/(2.0*PIXELS_PER_INCH)+Eye)*(ps.znear/ps.zscreen)*xfactor,
   -(ps.h/(2.0*PIXELS_PER_INCH))*(ps.znear/ps.zscreen)*yfactor,
   (ps.h/(2.0*PIXELS_PER_INCH))*(ps.znear/ps.zscreen)*yfactor,
   ps.znear, ps.zfar);
   
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(Eye,0.0,0.0);
  glTranslated(0,0,-ps.zscreen);           
   
    glRotatef(rotA,1,1,1);                 
    
    for(int y=0;y<QUAD_NUM;y++) 
     for(int x=0;x<QUAD_NUM;x++) {                    
                   
     if (boomMode) {
      glPushMatrix();
       
       if (renPass == 0) {
            quads[QUAD_NUM*x+y].x += quads[QUAD_NUM*x+y].velX;
      	    quads[QUAD_NUM*x+y].y += quads[QUAD_NUM*x+y].velY;
      	    quads[QUAD_NUM*x+y].z += quads[QUAD_NUM*x+y].velZ;
           
           
            if ( (quads[QUAD_NUM*x+y].x > X1)  || (quads[QUAD_NUM*x+y].x< X0)  ||
                 ((quads[QUAD_NUM*x+y].y > Y1) || (quads[QUAD_NUM*x+y].y< Y0)) ||
                 ((quads[QUAD_NUM*x+y].z > Z1) || (quads[QUAD_NUM*x+y].z< Z0))
                ) {
        		 quads[QUAD_NUM*x+y].velX = -quads[QUAD_NUM*x+y].velX;
        		 quads[QUAD_NUM*x+y].velY = -quads[QUAD_NUM*x+y].velY;
        		 quads[QUAD_NUM*x+y].velZ = -quads[QUAD_NUM*x+y].velZ;
          	     quads[QUAD_NUM*x+y].backway = true;
            }                 
        }                  
        
         float CX = x-quads[QUAD_NUM*x+y].x;
         float CY = y-quads[QUAD_NUM*x+y].y;
         float CZ = -quads[QUAD_NUM*x+y].z;

         glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
         
         if (quads[QUAD_NUM*x+y].backway && 
             (abs(quads[QUAD_NUM*x+y].y - y) < 0.05) && 
             (abs(quads[QUAD_NUM*x+y].x - x) < 0.05) &&
             (abs(quads[QUAD_NUM*x+y].z) < 0.05)
             ) {
                                    
    		 quads[QUAD_NUM*x+y].velX = 0;
    		 quads[QUAD_NUM*x+y].velY = 0;
    		 quads[QUAD_NUM*x+y].velZ = 0;
    
    		 quads[QUAD_NUM*x+y].x = x;
    		 quads[QUAD_NUM*x+y].y = y;  
    		 quads[QUAD_NUM*x+y].z = 0;
             
            quads[QUAD_NUM*x+y].backway = true;          
            
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);             
         } else {
                                              
                float fX = -CX+(QUAD_NUM/2-x);
                float fY = -CY+(QUAD_NUM/2-y);
                glTranslatef(-fX+0.5,-fY+0.5,0);
        		 glRotatef(quads[QUAD_NUM*x+y].rotX,1,0,0);	
        		 glRotatef(quads[QUAD_NUM*x+y].rotY,0,1,0);
        		 glRotatef(quads[QUAD_NUM*x+y].rotZ,0,0,1);
        		glTranslatef(fX-0.5,fY-0.5,0);
        		
        		if (renPass == 0) {                   
            		quads[QUAD_NUM*x+y].rotX += RX;   		
            		quads[QUAD_NUM*x+y].rotY += RY;
            		quads[QUAD_NUM*x+y].rotZ += RZ;       		     		        		 
                }
         }
         
               glTranslatef(CX,CY,CZ);                             		     		        		                    
      }  
  
       glBegin(GL_QUADS);               
        glNormal3f(0,0,1);             
        glVertex2f(-QUAD_NUM/2+x,-QUAD_NUM/2+y);                 
        glVertex2f(-QUAD_NUM/2+x+1,-QUAD_NUM/2+y);
        glVertex2f(-QUAD_NUM/2+x+1,-QUAD_NUM/2+y+1);
        glVertex2f(-QUAD_NUM/2+x,-QUAD_NUM/2+y+1);                           
       glEnd();       
       
       glBegin(GL_QUADS);              
        glNormal3f(0,-1,0);             
        glVertex3f(-QUAD_NUM/2+x,0,-QUAD_NUM/2+y);                 
        glVertex3f(-QUAD_NUM/2+x+1,0,-QUAD_NUM/2+y);
        glVertex3f(-QUAD_NUM/2+x+1,0,-QUAD_NUM/2+y+1);
        glVertex3f(-QUAD_NUM/2+x,0,-QUAD_NUM/2+y+1);                           
       glEnd();           

       glBegin(GL_QUADS);              
        glNormal3f(1,0,0);             
        glVertex3f(0,-QUAD_NUM/2+x,-QUAD_NUM/2+y);                 
        glVertex3f(0,-QUAD_NUM/2+x+1,-QUAD_NUM/2+y);
        glVertex3f(0,-QUAD_NUM/2+x+1,-QUAD_NUM/2+y+1);
        glVertex3f(0,-QUAD_NUM/2+x,-QUAD_NUM/2+y+1);                           
       glEnd();           
       
    if (boomMode)
      glPopMatrix();
    } 
    
    if(boomMode) {
                 
    int RetCount = 0;
    
    for(int y=0;y<QUAD_NUM;y++) 
     for(int x=0;x<QUAD_NUM;x++) {                    
       if (((quads[QUAD_NUM*x+y].x==x) &&      
          (quads[QUAD_NUM*x+y].y==y) &&      
          (quads[QUAD_NUM*x+y].z==0))) {
        RetCount++;                  
      }
    }
    boomMode = !(RetCount == QUAD_NUM*QUAD_NUM);
   }    
     
   if (ps.mblur) {
                                
	float bf = 0.80f;

	if (bf > 0){
		bf = powf(bf, 0.5);
		glAccum(GL_MULT, bf);
		glAccum(GL_ACCUM, 1.0f - bf);
		glAccum(GL_RETURN, 1);
	}
                     
   }
   
  } 
  
    glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
       
	glutSwapBuffers();
}

void reshape(int w, int h) {
     
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);	
	ps.w = w;
	ps.h = h;
}

void myKeyboard(unsigned char key, int x, int y) {
     
     GLfloat mat1_ambient[]   = { 0.1745, 0.01175, 0.01175, 0.55};
     GLfloat mat1_diffuse[]   = { 0.61424, 0.04136, 0.04136, 0.55};
     GLfloat mat1_specular[]  = { 0.727811, 0.626959, 0.626959, 0.55};
     GLfloat mat1_shininess[] = {76.8};

     GLfloat   mat2_ambient[]   = { 0.24, 0.22, 0.06, 1.0};
     GLfloat   mat2_diffuse[]   = { 0.34, 0.31, 0.09, 1.0};
     GLfloat   mat2_specular[]  = { 0.79, 0.72, 0.20, 1.0};
     GLfloat   mat2_shininess[] = {83.2};

     GLfloat   mat3_ambient[]   = { 0.02, 0.17, 0.02, 0.55};
     GLfloat   mat3_diffuse[]   = { 0.07, 0.061, 0.07, 0.55};
     GLfloat   mat3_specular[]  = { 0.77, 0.77, 0.77, 0.55};
     GLfloat   mat3_shininess[] = {76.8};

     GLfloat   mat4_ambient[]   = { 0.23, 0.23, 0.23, 1.0};
     GLfloat   mat4_diffuse[]   = { 0.27, 0.27, 0.27, 1.0};
     GLfloat   mat4_specular[]  = { 0.77, 0.77, 0.77, 1.0};
     GLfloat   mat4_shininess[] = {89.6};
     
     GLfloat light_ambientG[]  = {0.0,1.0,0.0,1.0};
     GLfloat light_diffuseG[]  = {0.0,1.0,0.0,1.0};
     GLfloat light_specularG[] = {0.0,1.0,0.0,1.0};
         
     GLfloat light_ambientB[]  = {0.0,0.0,1.0,1.0};
     GLfloat light_diffuseB[]  = {0.0,0.0,1.0,1.0};
     GLfloat light_specularB[] = {0.0,0.0,1.0,1.0};     
     
	switch (key) {
	  case 27:
		  exit(0);
		  break;
      case '1':
    
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat1_ambient);
             glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat1_diffuse);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat1_specular);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat1_shininess);
           break;		  
       case '2':  
            
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat2_ambient);
             glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat2_diffuse);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat2_specular);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat2_shininess);
             
             break;                                                 

       case '3':  
            
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat3_ambient);
             glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat3_diffuse);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat3_specular);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat3_shininess);
             
             break;                                                 

       case '4':  
            
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat4_ambient);
             glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat4_diffuse);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat4_specular);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat4_shininess);
             
             break;                                                 

       case 'g':  
          RBRender = false;  
          glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambientG);
          glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuseG);
          glLightfv(GL_LIGHT1, GL_SPECULAR, light_specularG);
             
           break;                                                 

       case 'b':  
          RBRender = true;  
          glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambientB);
          glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuseB);
          glLightfv(GL_LIGHT1, GL_SPECULAR, light_specularB);
                       
          break;                                                                          
        
        case 's':
             ps.stereo = (ps.stereo == 2) ? 1 : 2;
             
             initLight0();
             
             if (ps.stereo == 2)
             initLight1();
             
             if (ps.stereo == 1) {
                           
             glDisable(GL_LIGHT1);
              
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat2_ambient);
             glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat2_diffuse);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat2_specular);
             glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat2_shininess);
              
             }
          break;
       case 'm':
            ps.mblur = !ps.mblur;
        break;       
        
       case '+':
            if (ps.eye<10)
            ps.eye += 0.5;
        break;     

       case '-':
            if (ps.eye>0.5)
            ps.eye -= 0.5;
        break;     
        
       case '*':
            if (ps.zscreen<100)
            PIXELS_PER_INCH += 0.5;
        break;     

       case '/':
            if (PIXELS_PER_INCH>1)
            PIXELS_PER_INCH -= 0.5;
        break;  
       case ' ':
            initBoom();
        break;     
        
   }
}

void mySpecial(int key, int x, int y) {
     
  switch(key) {   
        case GLUT_KEY_UP:
            if (ps.eye<10)
            ps.eye += 0.5;
        break;     

       case GLUT_KEY_DOWN:
            if (ps.eye>0.5)
            ps.eye -= 0.5;
        break;     
   }
   

}

void mouseClick( int button, int state, int posX, int posY ) {
	if( state == GLUT_DOWN ){
		
		initBoom();
	}
	glutPostRedisplay();
	}

int main(int argc, char** argv)	{
    
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_DEPTH | GLUT_ACCUM);
	glutCreateWindow ("Boom 1.2");
	glutFullScreen();
	glutDisplayFunc(display); 
	glutReshapeFunc(reshape);
	glutMouseFunc(mouseClick);
	glutSpecialFunc(mySpecial);
	glutKeyboardFunc(myKeyboard);
	glutIdleFunc(display);
    init();
	glutMainLoop();
	
	return 0;
}



