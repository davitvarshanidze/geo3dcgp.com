#include "utils/glUtils.h"

GLuint Tex1ID;
GLuint Tex2ID;
GLuint Tex3ID;
GLuint Tex4ID;
GLuint Tex5ID;
GLuint Tex6ID;

GLuint HeartTex;
GLuint HeartID;

float heartBit  = 0.0f;
int   bitDir    = 0; 
float rotAngle  = 0.0f;
int   showHeart = 0;  
float animKoef  = 0;

void drawArrow() {
  
  glPushMatrix();
    glLineWidth(2);                        
    
    glColor3f(0,1,0);
    glBegin(GL_LINES);
    
        glVertex3f(0,0,0);
        glVertex3f(0,2.5,0);                        
        
        glVertex3f(0,0.15,0);
        glVertex3f(0.14,0,0);                        
        
        glVertex3f(0,0.15,0);
        glVertex3f(-0.14,0,0);                        
        
        glVertex3f(0,0.45,0);
        glVertex3f(0.14,0.3,0);                        
        
        glVertex3f(0,0.45,0);
        glVertex3f(-0.14,0.3,0);                        
    
    glEnd();              
    
    glTranslatef(0,2.5,0);                                                         
    glRotatef(-90,1,0,0);
    glutSolidCone(0.05, 0.2, 10, 10 );            
    
    glLineWidth(0.5);        
    glPopMatrix();
}

void drawCube() {
 
     selectTexture(Tex1ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( -1.0f,-1.0f, 1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( 1.0f,-1.0f, 1.0f  );
		glTexCoord2f(0.0f,0.0f); glVertex3f( 1.0f, 1.0f-animKoef, 1.0f+animKoef  );			
		glTexCoord2f(1.0f,0.0f); glVertex3f( -1.0f, 1.0f-animKoef, 1.0f+animKoef );			
	glEnd();

    selectTexture(Tex2ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( -1.0f,-1.0f,  -1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( -1.0f, 1.0f-animKoef,  -1.0f-animKoef );
		glTexCoord2f(0.0f,0.0f); glVertex3f(  1.0f, 1.0f-animKoef,  -1.0f-animKoef );			
		glTexCoord2f(1.0f,0.0f); glVertex3f(  1.0f, -1.0f, -1.0f );			
	glEnd();

    selectTexture(Tex3ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( -1.0f, 1.0f+animKoef*10,-1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( -1.0f, 1.0f+animKoef*10, 1.0f );
		glTexCoord2f(0.0f,0.0f); glVertex3f(  1.0f, 1.0f+animKoef*10, 1.0f );
		glTexCoord2f(1.0f,0.0f); glVertex3f(  1.0f, 1.0f+animKoef*10,-1.0f );			
	glEnd();

    selectTexture(Tex4ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( -1.0f,-1.0f,-1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( 1.0f,-1.0f,-1.0f );
		glTexCoord2f(0.0f,0.0f); glVertex3f( 1.0f,-1.0f, 1.0f );
		glTexCoord2f(1.0f,0.0f); glVertex3f( -1.0f,-1.0f, 1.0f );			
	glEnd();

    selectTexture(Tex5ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( 1.0f,-1.0f,-1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( 1.0f+animKoef, 1.0f-animKoef,-1.0f );
		glTexCoord2f(0.0f,0.0f); glVertex3f( 1.0f+animKoef, 1.0f-animKoef, 1.0f );
		glTexCoord2f(1.0f,0.0f); glVertex3f( 1.0f,-1.0f, 1.0f );			
	glEnd();
    
    selectTexture(Tex6ID);     
  	glBegin(GL_QUADS);								
		glTexCoord2f(1.0f,1.0f); glVertex3f( -1.0f,-1.0f,-1.0f );		 
		glTexCoord2f(0.0f,1.0f); glVertex3f( -1.0f,-1.0f, 1.0f );
		glTexCoord2f(0.0f,0.0f); glVertex3f( -1.0f-animKoef, 1.0f-animKoef, 1.0f );
		glTexCoord2f(1.0f,0.0f); glVertex3f( -1.0f-animKoef, 1.0f-animKoef,-1.0f );			
	glEnd();    
}

void drawCoordinates() {
     
   if (showHeart == 0) {
        glDisable(GL_LIGHTING);         
        glColor3f(0,0,0);
            renderBitmapString(-1,-1,1, GLUT_BITMAP_HELVETICA_18, "0. (-1,-1,1)");
            renderBitmapString(1,-1,1,  GLUT_BITMAP_HELVETICA_18, "1. (1,-1,1)");
            renderBitmapString(1,1,1,   GLUT_BITMAP_HELVETICA_18, "2. (1,1,1)");
            renderBitmapString(-1,1,1,  GLUT_BITMAP_HELVETICA_18, "3. (-1,1,1)");
            renderBitmapString(-1,-1,-1,GLUT_BITMAP_HELVETICA_18, "4. (-1,-1,-1)");
            renderBitmapString(-1,1,-1, GLUT_BITMAP_HELVETICA_18, "5. (-1,1,-1)");
            renderBitmapString(1,1,-1,  GLUT_BITMAP_HELVETICA_18, "6. (1,1,-1)");
            renderBitmapString(1,-1,-1, GLUT_BITMAP_HELVETICA_18, "7. (1,-1,-1)");       
        glColor3f(1,1,1);   
        glEnable(GL_LIGHTING);   
   }  
}        

void renderGraphics( void )  {
     
    gluLookAt(0,0,4,0,0,0,0,1,0); 
    
    if  ((showHeart == 0) || (showHeart == 1)) 
     rotAngle += 0.04;
    else 
     rotAngle -= 0.04;
    
    if (heartBit>0.012 || heartBit < -0.02) 
     bitDir = -bitDir;
     
    heartBit += 0.001*(float)bitDir;        
    
    if (showHeart == 0)     
    glRotatef( rotAngle, cos(rotAngle/2), cos(rotAngle/3), sin(rotAngle/2) );
    
    if (rotAngle > 360 ) rotAngle = 0;
    
    if (showHeart == 0)
    drawAxis(2);
    
    if (showHeart == 1) {
     if (animKoef < 2)
      animKoef  += 0.01f;
      glRotatef(rotAngle*40,0,1,0);
    } 
    
   if (showHeart == 2) {
    if (animKoef > 0)
      animKoef  -= 0.01f;
      glRotatef(rotAngle*40,0,1,0);
    } 
      
    drawCube();

   if (showHeart != 0) {

     glColor3f(0.5, 0.3 ,0.2);                 
     glEnable(GL_LIGHTING);           
     glPushMatrix(); 
     glPushAttrib(GL_TEXTURE_BIT);
     
       if (animKoef < 1.83 && showHeart==1) {       
                    
        enableAutoTexturing(GL_SPHERE_MAP);
        selectTexture(HeartTex);     
                    
        GLfloat mat_emission1[] = { 0.0, 0.0, 0.0, 0.0 };	               
        GLfloat mat_specular1[] = { 0.2, 0.2, 0.2, 0.0 };
        GLfloat mat_diffuse1[] =  { 0.5, 0.5, 0.5, 0.0 };
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, mat_emission1);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular1);            
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse1);            
        
        disableAutoTexturing();
       }
       else {
        glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_COMBINE);
        glTexEnvi(GL_TEXTURE_ENV,GL_COMBINE_RGB,GL_MODULATE);
        glTexEnvi(GL_TEXTURE_ENV,GL_SOURCE0_RGB,GL_PRIMARY_COLOR);
            
        GLfloat mat_emission1[] = { 0.7, 0.0, 0.0, 0.0 };	               
        GLfloat mat_specular1[] = { 0.0, 0.0, 0.0, 0.0 };
        GLfloat mat_diffuse1[] =  { 0.0, 0.0, 0.0, 0.0 };
        
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, mat_emission1);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular1);            
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse1);            
       }
                       
        glScalef(0.04+heartBit,0.04+heartBit,0.04+heartBit);
        glCallList(HeartID);                 

     glPopMatrix();     
     
       if (showHeart==1 || showHeart==2) { 
                                            
        glPushMatrix();                                                               
                
        glRotatef(180,30,20,-20);

        if (animKoef < 1.83 && showHeart==1 )
          glTranslatef(0,-20+animKoef*10,0);                    
        else {            
          if (bitDir==0) {   
           bitDir   = 1;
           heartBit = 0;
          }
           glTranslatef(0,-1.3,0);
        }
                         
        GLfloat mat_emission1[] = { 0.0, 1.0, 0.0, 0.0 };	               
        GLfloat mat_ambient1[]  = { 0.0, 1.0, 0.0, 0.0 };
        GLfloat mat_diffuse1[]  = { 0.0,  1.0, 0.0, 0.0 };
        glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission1);
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient1);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse1);
                         
        drawArrow();

       glPopMatrix();
     }        
    glPopAttrib();   
    
    GLfloat mat_ambient[]  = { 0.1, 0.1, 0.1, 1.0 };
    GLfloat mat_diffuse[]  = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat mat_specular[] = { 0.1, 0.1, 0.1, 1.0 };
    GLfloat mat_emission[] = { 0.2, 0.2, 0.2, 0.0 };	
    GLfloat mat_Shininess  = {20};
    
    glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
    
    
    glColor3f(1, 1 ,1);
   }
   else {
        GLfloat mat_emission[] = { 0.0, 0.0, 0.0, 0.0 };	               
        glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);        
   }
   
   glDisable(GL_TEXTURE_2D);   
   
   drawCoordinates();     
   
}


/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
     
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;     
    case '1':
          showHeart = 0;
          animKoef  = 0;
          bitDir    = 0; 
         break;           
    case '2':
          showHeart = 1;
         break;           
    case '3':
          showHeart = 2;
         break;                    
    default:     
      break;
  }
}



int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"Love cube");
     

        glShadeModel(GL_SMOOTH);
        glEnable(GL_LIGHTING);
        glEnable(GL_NORMALIZE);
        
        GLfloat position[]		 = { 20.0, 10.0, 5.0, 0.0 };
        GLfloat diffuse[]		 = { 1.0, 1.0, 1.0, 1.0 };
        GLfloat specular[]		 = { 1.0, 1.0, 1.0, 1.0 };
        
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_POSITION, position);
        
        glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
        glLightfv(GL_LIGHT0, GL_POSITION, position);
        
        glEnable(GL_LIGHT0);
        
        GLfloat mat_ambient[]  = { 0.1, 0.1, 0.1, 1.0 };
        GLfloat mat_diffuse[]  = { 0.8, 0.8, 0.8, 1.0 };
        GLfloat mat_specular[] = { 0.1, 0.1, 0.1, 1.0 };
        GLfloat mat_emission[] = { 0.2, 0.2, 0.2, 0.0 };	
        GLfloat mat_Shininess  = {20};
        
        glMaterialfv(GL_FRONT, GL_AMBIENT,  mat_ambient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE,  mat_diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
        glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
     
      Tex1ID = loadJpegAs2DTexture("textures/heart1.jpg");
      Tex2ID = loadJpegAs2DTexture("textures/heart2.jpg");
      Tex3ID = loadJpegAs2DTexture("textures/heart3.jpg");
      Tex4ID = loadJpegAs2DTexture("textures/heart4.jpg");
      Tex5ID = loadJpegAs2DTexture("textures/heart5.jpg");
      Tex6ID = loadJpegAs2DTexture("textures/heart6.jpg");
      
      HeartTex = loadJpegAs2DTexture("textures/model_base.jpg");
      HeartID  = load3dsAsList("models/model.3ds");  
	            
      glClearColor( 0.35f, 0.53f, 0.7f, 1.0f );
      
      glutMainLoop();
}
