#include <GL/freeglut.h>
#include <stdlib.h>

//GL_V2F
//GL_V3F
//GL_C4UB_V2F
//GL_C4UB_V3F
//GL_C3F_V3F
//GL_N3F_V3F
//GL_C4F_N3F_V3F
//GL_T2F_V3F
//GL_T4F_V4F
//GL_T2F_C4UB_V3F
//GL_T2F_C3F_V3F
//GL_T2F_N3F_V3F
//GL_T2F_C4F_N3F_V3F
//GL_T4F_C4F_N3F_V4F

struct Vertex
	{
	// GL_C3F_V3F
	float r, g, b;
	float x, y, z;
	};

Vertex g_cubeVertices[] =
	{
		{ 1.0f,0.0f,0.0f,  -1.0f,-1.0f, 1.0f }, // 0
		{ 0.0f,1.0f,0.0f,   1.0f,-1.0f, 1.0f }, // 1
		{ 0.0f,0.0f,1.0f,   1.0f, 1.0f, 1.0f }, // 2
		{ 1.0f,1.0f,0.0f,  -1.0f, 1.0f, 1.0f }, // 3
		{ 1.0f,0.0f,1.0f,  -1.0f,-1.0f,-1.0f }, // 4
		{ 0.0f,1.0f,1.0f,  -1.0f, 1.0f,-1.0f }, // 5
		{ 1.0f,1.0f,1.0f,   1.0f, 1.0f,-1.0f }, // 6
		{ 1.0f,0.0f,0.0f,   1.0f,-1.0f,-1.0f }, // 7
	};

GLubyte g_cubeIndices[] =
	{
	0, 1, 2, 3, // Quad 0
	4, 5, 6, 7, // Quad 1
	5, 3, 2, 6, // Quad 2
	4, 7, 1, 0, // Quad 3
	7, 6, 2, 1, // Quad 4
	4, 0, 3, 5  // Quad 5
	};

void init(void) {
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);

	glInterleavedArrays( GL_C3F_V3F, 0, g_cubeVertices );
}

void display(void) {

	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	static float rotA = 0;
	rotA =  rotA + 0.1;

	if ( rotA > 360 ) rotA = 0;

	glRotatef(rotA,1,1,1);
	
	
	glDrawElements( GL_QUADS, 24, GL_UNSIGNED_BYTE, g_cubeIndices );

	glutSwapBuffers();
	}

void reshape(int w, int h) {
	glViewport (0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60,w/h,1,500);
	gluLookAt(0.0, 0.0, 4.0,  // Camera position
		0.0,0.0, 0.0,         // Look-at point
		0.0, 1.0, 0.0 );        // Up vector
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	  case 27:
		  exit(0);
		  break;
		}

	}

void specialkeys( int key, int x, int y ) {
	switch (key) {
  case GLUT_KEY_DOWN:
	  break;
  case GLUT_KEY_UP:
	  break;
  case GLUT_KEY_LEFT:	 
	  break;
  case GLUT_KEY_RIGHT: 	
	  break;
  default:
	  break;
		}
	glutPostRedisplay();
	}

int main(int argc, char** argv)
	{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize (800, 600); 
	glutInitWindowPosition (400, 100);
	glutCreateWindow ("Base 1.0");
	init();
	glutDisplayFunc(display); 
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(specialkeys);
	glutIdleFunc(display);
	glutMainLoop();
	return 0;
	}
