#include "utils/glUtils.h"

void renderGraphics(void) {

  gluLookAt(0.0, 0.6, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 ); 
  
  
}

int main(int argc, char** argv) {
             
    initOpenGL(argc, argv, 800,600, 
    GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_STENCIL ,
    "Advanced Texturing Base 1.0");
	
	init();					

	glutMainLoop();
		
	return 0;
}
