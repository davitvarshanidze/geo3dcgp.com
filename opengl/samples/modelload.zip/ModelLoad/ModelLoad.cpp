#include "utils/glUtils.h"

GLuint mashaID;
GLuint activeTextID;

void renderGraphics( void )  {
     
    gluLookAt(0,-100,170,0,200,0,0,1,0); 
    
    static float rotAngle = 0;
    
    rotAngle += 0.5;
    
    glRotatef( rotAngle, 0, 0, 1 );
    
    selectTexture(activeTextID);

    glCallList(mashaID);
    
}


/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;     
    case '1':
          glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
         break;  
    case '2':
         glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
         break;           
    case '3':
         glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
         break;                              
    default:     
      break;
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"Model Loading and Texturing");
     
      mashaID      = load3dsAsList("models/masha.3ds");      
      activeTextID = loadJpegAs2DTexture("textures/base.jpg");
      
      enableAutoTexturing(GL_SPHERE_MAP);
      
      glutMainLoop();
}
