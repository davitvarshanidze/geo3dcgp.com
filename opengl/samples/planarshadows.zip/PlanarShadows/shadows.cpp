#include "utils/glUtils.h"

float  g_fSpinX_L =   0.0f;
float  g_fSpinY_L = -10.0f;

float  g_fSpinX_R =   0.0f;
float  g_fSpinY_R =   0.0f;

float g_shadowMatrix[16];
float g_lightPosition[] = { -4.0f, 6.0f, -1.0f, 1.0f }; 

struct Vertex
{
    float nx, ny, nz;
    float x, y, z;
};

Vertex g_floorQuad[] =
{
    { 0.0f, 1.0f,  0.0f,  -5.0f, 0.0f, -5.0f },
    { 0.0f, 1.0f,  0.0f,  -5.0f, 0.0f,  5.0f },
    { 0.0f, 1.0f,  0.0f,   5.0f, 0.0f,  5.0f },
    { 0.0f, 1.0f,  0.0f,   5.0f, 0.0f, -5.0f },
};

void buildShadowMatrix( float fMatrix[16], float fLightPos[4], float fPlane[4] )
{
    float dotp;

    // Calculate the dot-product between the plane and the light's position
    dotp = fPlane[0] * fLightPos[0] + 
           fPlane[1] * fLightPos[1] + 
           fPlane[1] * fLightPos[2] + 
           fPlane[3] * fLightPos[3];

    // First column
    fMatrix[0]  = dotp - fLightPos[0] * fPlane[0];
    fMatrix[4]  = 0.0f - fLightPos[0] * fPlane[1];
    fMatrix[8]  = 0.0f - fLightPos[0] * fPlane[2];
    fMatrix[12] = 0.0f - fLightPos[0] * fPlane[3];

    // Second column
    fMatrix[1]  = 0.0f - fLightPos[1] * fPlane[0];
    fMatrix[5]  = dotp - fLightPos[1] * fPlane[1];
    fMatrix[9]  = 0.0f - fLightPos[1] * fPlane[2];
    fMatrix[13] = 0.0f - fLightPos[1] * fPlane[3];

    // Third column
    fMatrix[2]  = 0.0f - fLightPos[2] * fPlane[0];
    fMatrix[6]  = 0.0f - fLightPos[2] * fPlane[1];
    fMatrix[10] = dotp - fLightPos[2] * fPlane[2];
    fMatrix[14] = 0.0f - fLightPos[2] * fPlane[3];

    // Fourth column
    fMatrix[3]  = 0.0f - fLightPos[3] * fPlane[0];
    fMatrix[7]  = 0.0f - fLightPos[3] * fPlane[1];
    fMatrix[11] = 0.0f - fLightPos[3] * fPlane[2];
    fMatrix[15] = dotp - fLightPos[3] * fPlane[3];
}

void findPlane( GLfloat plane[4], GLfloat v0[3], GLfloat v1[3], GLfloat v2[3] )
{
    GLfloat vec0[3], vec1[3];

    // Need 2 vectors to find cross product
    vec0[0] = v1[0] - v0[0];
    vec0[1] = v1[1] - v0[1];
    vec0[2] = v1[2] - v0[2];

    vec1[0] = v2[0] - v0[0];
    vec1[1] = v2[1] - v0[1];
    vec1[2] = v2[2] - v0[2];

    // Find cross product to get A, B, and C of plane equation
    plane[0] =   vec0[1] * vec1[2] - vec0[2] * vec1[1];
    plane[1] = -(vec0[0] * vec1[2] - vec0[2] * vec1[0]);
    plane[2] =   vec0[0] * vec1[1] - vec0[1] * vec1[0];

    plane[3] = -(plane[0] * v0[0] + plane[1] * v0[1] + plane[2] * v0[2]);
}

void renderFloor()
{
    glColor3f( 1.0f, 1.0f, 1.0f );
    glInterleavedArrays( GL_N3F_V3F, 0, g_floorQuad );
    glDrawArrays( GL_QUADS, 0, 4 );
}

void renderGraphics( void )  {
     
    gluLookAt(0,2,10,0,0,0,0,1,0);
   
    GLfloat shadowPlane[4];
    GLfloat v0[3], v1[3], v2[3];

    v0[0] = g_floorQuad[0].x;
    v0[1] = g_floorQuad[0].y;
    v0[2] = g_floorQuad[0].z;

    v1[0] = g_floorQuad[1].x;
    v1[1] = g_floorQuad[1].y;
    v1[2] = g_floorQuad[1].z;

    v2[0] = g_floorQuad[2].x;
    v2[1] = g_floorQuad[2].y;
    v2[2] = g_floorQuad[2].z;

    findPlane( shadowPlane, v0, v1, v2 );

    buildShadowMatrix( g_shadowMatrix, g_lightPosition, shadowPlane );
    
    glRotatef( -g_fSpinY_L, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX_L, 0.0f, 1.0f, 0.0f );

    renderFloor();


    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);

    glColor3f(0.2f, 0.2f, 0.2f);
    glPushMatrix();
    {
        glMultMatrixf((GLfloat *)g_shadowMatrix);

        glTranslatef( 0.0f, 2.5f, 0.0f );
        glRotatef( -g_fSpinY_R, 1.0f, 0.0f, 0.0f );
        glRotatef( -g_fSpinX_R, 0.0f, 1.0f, 0.0f );
        glutSolidTeapot( 1.0 );
    }
    glPopMatrix();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glDisable( GL_LIGHTING );

    glPushMatrix();
    {
        static float cTime = 0;
        static int   sign  = 1;
        
         cTime += sign*0.002; 
        
        if (cTime>0.2 || cTime<-0.2) sign=-sign;
              
        g_lightPosition[0] += cTime/2;
        g_lightPosition[1] += cTime/10;
        
        glLightfv( GL_LIGHT0, GL_POSITION, g_lightPosition );
        glTranslatef( g_lightPosition[0], g_lightPosition[1], g_lightPosition[2] );

        glColor3f(1.0f, 1.0f, 0.5f);
        glutSolidSphere( 0.1, 32, 32 );
    }
    glPopMatrix();

    glEnable( GL_LIGHTING );

    glPushMatrix();
    {
        glTranslatef( 0.0f, 2.5f, 0.0f );
        glRotatef( -g_fSpinY_R, 1.0f, 0.0f, 0.0f );
        glRotatef( -g_fSpinX_R, 0.0f, 1.0f, 0.0f );
        glutSolidTeapot( 1.0 );
    }
    glPopMatrix();       
}


void programInit(void) {

    glClearColor( 0.35f, 0.53f, 0.7f, 1.0f );
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);

    float lightAmbient[] = {0.2f, 0.2f, 0.2f, 1.0f};
    float lightDiffuse[] = {1.0, 1.0, 1.0, 1.0}; 
    float lightSpecular[] = {1.0, 1.0, 1.0, 1.0};
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
}



int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 800,600, GLUT_RGB | GLUT_DOUBLE ,"OpenGL Planar Shadows");              
      
      programInit();      
      
      glutMainLoop();
}

