#ifndef __GL_UTILS_H__
#define __GL_UTILS_H__


#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
#include <math.h>
#include <time.h>
#include <WinSock.h>
#include <windows.h>
#include <mmsystem.h>

#include <GL/freeglut.h>

#include "loadjpeg.h"
#include "load3ds.h"

void renderGraphics( void );  
void base_display( void );
void reshape( int w, int h );

void enableSphereTexturing();
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle );
void keyboard( unsigned char key, int x, int y );  

void selectTexture(int texID);
void enableAutoTexturing(unsigned int mode, GLfloat* plane);

/**
void enableAutoTexturing(unsigned int mode, GLfloat* plane=0)
**/
void enableAutoTexturing(unsigned int mode, GLfloat* plane=0) {
     
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);     

  glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, mode);
  glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, mode);       
  
  if ( mode != GL_SPHERE_MAP ) {
       glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, mode);
       glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, mode);        
      if (plane!=0) {
    
        glTexGenfv(GL_S, GL_OBJECT_PLANE, plane);
        glTexGenfv(GL_T, GL_OBJECT_PLANE, plane);                
      }
  }
}

/**
void selectTexture(int texID)
**/
void selectTexture(int texID) {
     
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texID);   
}

/**
GLuint  loadJpegAs2DTexture(char *texturePath)
**/
GLuint  loadJpegAs2DTexture(char *texturePath) {

    int				width,height;
    unsigned char	*data;
    GLuint          texID = 0;
    
    glGenTextures(1, &texID);
   
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR );	
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR ); 
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT );	
    glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT ); 

        
    glBindTexture(GL_TEXTURE_2D, texID);
    
    if((data = LoadJPEG(texturePath,&width,&height))) {
    
    	gluBuild2DMipmaps(GL_TEXTURE_2D,4,width,height,GL_RGBA,GL_UNSIGNED_BYTE,data);
    	free(data);	 
    }
   
   return texID;
}

/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;              
    default:     
      break;
  }
}

/**
void reshape( int w, int h )
**/
void reshape( int w, int h )
{
  glViewport( 0, 0, w, h );
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity( );            
  if ( h==0 ) 
     gluPerspective ( 80, ( float ) w, 1.0, 5000.0 );
  else
     gluPerspective ( 80, ( float ) w / ( float ) h, 1.0, 5000.0 );
  glMatrixMode( GL_MODELVIEW );  
  glLoadIdentity( ); 
}

/**
void base_display( void )
**/
void base_display( void ) {
  
	static int cTime = 0; 

	if ( glutGet(GLUT_ELAPSED_TIME) - cTime < 1000/60  ) return;

	cTime = glutGet(GLUT_ELAPSED_TIME);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glLoadIdentity( );

   renderGraphics();   
  
   glutSwapBuffers();    
}

/**
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle )
**/
void initOpenGL( int argc, char** argv, int width, int height, unsigned int displayMode,char* windowTitle )  {
	
  glutInit( &argc, argv ); 
  glutInitDisplayMode( displayMode ); 
  glutInitWindowSize( width, height ); 
  glutCreateWindow( windowTitle ); 
    
      glShadeModel(GL_SMOOTH);							
      glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				
      glClearDepth(1.0f);								
      glEnable(GL_DEPTH_TEST);						
      glDepthFunc(GL_LEQUAL);							
      glEnable ( GL_COLOR_MATERIAL );
      glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

  glutDisplayFunc( base_display );  
  glutIdleFunc( base_display );  
  glutReshapeFunc( reshape );
  glutKeyboardFunc( keyboard ); 
}


#endif /* __GL_UTILS_H__ */
