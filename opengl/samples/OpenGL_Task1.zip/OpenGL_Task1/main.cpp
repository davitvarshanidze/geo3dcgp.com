#include <GL/freeglut.h>

#include <stdlib.h>
#include <math.h>

#define GL_PI 3.14

float xRot = 30;
float yRot = 30;

void SetupRC()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f );
    glColor3f(0.0f, 1.0f, 0.0f);
    glShadeModel(GL_FLAT);
}


void RenderScene(void)
{
    GLfloat x,y,angle; 
    int iPivot = 1; 

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glPushMatrix();
    glTranslatef(0,0,-80);    
    
    glBegin(GL_TRIANGLE_FAN);
    
    glVertex3f(0.0f, 0.0f, 75.0f);
    for(angle = 0.0f; angle < (2.0f*GL_PI); angle += (GL_PI/8.0f))
    {              
        x = 50.0f*sin(angle);
        y = 50.0f*cos(angle);
        
        if((iPivot %2) == 0)
        glColor3f(0.0f, 1.0f, 0.0f);
        else
        glColor3f(1.0f, 0.0f, 0.0f);
        
        iPivot++;
        
        glVertex2f(x, y);
    }
    glEnd();

    glPopMatrix();
    glutSwapBuffers ();
}

void reshape ( int w, int h )   
{
  glViewport( 0, 0, w, h );
  glMatrixMode( GL_PROJECTION );  
  glLoadIdentity( );                
  if ( h==0 )  
     gluPerspective ( 80, ( float ) w, 1.0, 5000.0 );
  else
     gluPerspective ( 80, ( float ) w / ( float ) h, 1.0, 5000.0 );
  glMatrixMode( GL_MODELVIEW );  
  glLoadIdentity( );    
}

void keyboard ( unsigned char key, int x, int y )  
{
  switch ( key ) 
  {
    case 27:        
      exit ( 0 );   
      break;        
    default:        
      break;
  }
}

int main ( int argc, char** argv )   
{
  glutInit            ( &argc, argv );
  glutInitDisplayMode ( GLUT_RGB | GLUT_DOUBLE ); 
  glutInitWindowSize  ( 640, 480 ); 
  glutCreateWindow    ( "OpenGL Task 1" ); 
  glutDisplayFunc     ( RenderScene );  
  glutKeyboardFunc    ( keyboard );
  glutReshapeFunc     ( reshape );
  SetupRC             ( );
  glutMainLoop        ( );          
}
