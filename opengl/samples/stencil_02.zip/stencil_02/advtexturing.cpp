#include "utils/glUtils.h"

void renderGraphics(void) {

    glLoadIdentity();
    gluLookAt(0.0, 0.6, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 );
    glRotatef(30,1,0,0);
    glBindTexture(GL_TEXTURE_2D, BalltxID);
    glTranslatef(0,1,0);
    drawBall();
    glBindTexture(GL_TEXTURE_2D, EnvtxID);
    glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    drawBall();
    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_BLEND);
    glTranslatef(0,-1,0);
    glColorMask(0,0,0,0);
    glEnable(GL_STENCIL_TEST);
    glStencilFunc(GL_ALWAYS, 1, 1);
    glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
    glDisable(GL_DEPTH_TEST);
    drawFloor();
    double eqr[] = {0.0f,-1.0f, 0.0f, 0.0f};
    glEnable(GL_DEPTH_TEST);
    glColorMask(1,1,1,1);
    glStencilFunc(GL_EQUAL, 1, 1);
    glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
    glEnable(GL_CLIP_PLANE0);
    glClipPlane(GL_CLIP_PLANE0, eqr);
    glPushMatrix();
    glScalef(1.0f, -1.0f, 1.0f);
    glLightfv(GL_LIGHT0, GL_POSITION, LightPos);
    glTranslatef(0.0f, 1, 0.0f);
    glBindTexture(GL_TEXTURE_2D, BalltxID);
    drawBall();
    glBindTexture(GL_TEXTURE_2D, EnvtxID);
    glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    drawBall();
    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_BLEND);
    glPopMatrix();
    glDisable(GL_CLIP_PLANE0);
    glDisable(GL_STENCIL_TEST);
    glLightfv(GL_LIGHT0, GL_POSITION, LightPos);
    glEnable(GL_BLEND);
    glDisable(GL_LIGHTING);
    glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    drawFloor();
    glEnable(GL_LIGHTING);
    glDisable(GL_BLEND);
}

int main(int argc, char** argv) {
             
    initOpenGL(argc, argv, 800,600, 
    GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_STENCIL ,
    "Stencil Demo 2.0");
	
	init();					

	glutMainLoop();
		
	return 0;
}
