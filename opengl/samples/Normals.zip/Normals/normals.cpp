#include "utils/glUtils.h"

typedef float Vertex[3];
typedef int Triangle[3];

Vertex verts[10] = 
{{-1,1,-1},  {0,1.2,-1}, {1,1,-1}, 
 {-1.5,0,-1},{-0.5,0,0}, {0.5,0,0}, 
 {1.5,0,-1}, {-1,-1,-1}, {0,-1.2,-1}, 
 {1,-1,-1}};

Triangle Tris[10] = {
         {0,1,4},{1,5,4},{1,2,5},
         {0,4,3},{2,6,5},{3,4,7},
         {4,8,7},{4,5,8},{5,9,8},
         {5,6,9}};

Vertex facenormals[10];
Vertex vertnormals[10];

bool bFaceNormals = true;
bool bWireframe   = true;
bool bDrawNormals = true;


void CalcNorms()
{
	//Calculate face normals first
	for(int x = 0; x < 10; x++)
	{
        CVector3 vec1(verts[Tris[x][2]]);      
        CVector3 vec2(verts[Tris[x][1]]);
        CVector3 vec3(verts[Tris[x][0]]);
            
		CVector3 vTmp = CalcFaceNormal(vec1,vec2,vec3);
		memcpy(facenormals[x], vTmp.Get(), 12);
	}
	//Calculate the vertex normals
	for(int x = 0; x < 10; x++)
	{
		int iShared[10];  //Indices of shared faces
		int iNumShared = 0;   //Number of faces that share vertex
		
		//first find out which faces share the vertex
		for(int y = 0; y < 10; y++)
		{
			for(int z = 0; z < 3; z++)
			{
				if(Tris[y][z] == x)
				{
					iShared[iNumShared] = y;
					iNumShared ++;
				}
			}
		}
		//Calculate a normal by averaging the face normals of the shared faces
		CVector3 finalNorm;
		for(int y = 0; y < iNumShared; y++)
		{
			finalNorm += facenormals[iShared[y]];
		}
		finalNorm /= (float)iNumShared;
		memcpy(&vertnormals[x], finalNorm.Get(), 12); 
	}
}



void renderGraphics( void )  {
      
   	static float rot = 0;

	glColor3f(1, 1, 1);

	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -4.0f);
	//Draw light
	glColor3f(1.0f, 1.0f, 0.0f);
	glPointSize(8);
	glBegin(GL_POINTS);
	glVertex3f(0.0f, 3.5f, 0.0f);
	glEnd();
	
	glEnable(GL_LIGHTING);
	glRotatef(rot, 1.0f, 1.0f, 1.0f);

	//Draw the mesh
	//Draw with one normal per face
	if(bFaceNormals)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glBegin(GL_TRIANGLES);
		for(int x = 0; x < 10; x++)
		{
			glNormal3fv( facenormals[x] );
			glVertex3fv( verts[Tris[x][0]] );
			glVertex3fv( verts[Tris[x][1]] );
			glVertex3fv( verts[Tris[x][2]] );
		}
		glEnd();
		
		if(bDrawNormals)
		{
			//Draw the normals
			glDisable(GL_LIGHTING);
			glBegin(GL_LINES);
			for(int x = 0; x < 10; x++)
			{
				CVector3 vCenter = (CVector3(verts[Tris[x][0]]) + CVector3(verts[Tris[x][1]]) + CVector3(verts[Tris[x][2]])) / 3;
				CVector3 vEnd = vCenter + CVector3(facenormals[x]);
				glColor3f(0.0f, 0.0f, 1.0f);
				glVertex3fv(vCenter.Get());
				glColor3f(0.0f, 1.0f, 0.0f);
				glVertex3fv(vEnd.Get());
			}
			glEnd();
		}
	}


	//Use vertex normals
	else
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glBegin(GL_TRIANGLES);
		for(int x = 0; x < 10; x++)
		{
			glNormal3fv( vertnormals[Tris[x][0]] );
			glVertex3fv( verts[Tris[x][0]] );
			glNormal3fv( vertnormals[Tris[x][1]] );
			glVertex3fv( verts[Tris[x][1]] );
			glNormal3fv( vertnormals[Tris[x][2]] );
			glVertex3fv( verts[Tris[x][2]] );
		}
		glEnd();
		if(bDrawNormals)
		{
			//Draw the normals
			glDisable(GL_LIGHTING);
			glBegin(GL_LINES);
			for(int x = 0; x < 10; x++)
			{
				glColor3f(0.0f, 0.0f, 1.0f);
				glVertex3fv(verts[x]);
				CVector3 vEnd = CVector3(verts[x]) + CVector3(vertnormals[x]);
				glColor3f(0.0f, 1.0f, 0.0f);
				glVertex3fv(vEnd.Get());
			}
			glEnd();
		}
	}
    
	
	if(bWireframe)
	{
		glDisable(GL_LIGHTING);
		glColor3f(1.0f, 0.0f, 1.0f);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glBegin(GL_TRIANGLES);
		for(int x = 0; x < 10; x++)
		{
			glVertex3fv( verts[Tris[x][0]]);
			glVertex3fv( verts[Tris[x][1]]);
			glVertex3fv( verts[Tris[x][2]]);
		}
		glEnd();
	}

	rot+=0.2f;    
}


/**
 void keyboard( unsigned char key, int x, int y )
**/
void keyboard( unsigned char key, int x, int y )  {
  switch ( key ) {
    case 27:     
      exit ( 0 );
      break;     
    case '1':
         bFaceNormals = !bFaceNormals;
         break;  
    case '2':
         bWireframe = !bWireframe;
         break;           
    case '3':
         bDrawNormals = !bDrawNormals;
         break;                    
  }
}

int main( int argc, char** argv ) {
    
      initOpenGL(argc, argv, 640,480, GLUT_RGB | GLUT_DOUBLE ,"Normals");
     
        static float LightAmbient [] = { 0.5f, 0.5f, 0.5f, 1.0f }; 
        static float LightDiffuse [] = { 1.0f, 1.0f, 1.0f, 1.0f };
        static float LightPosition [] = { 0, 3.5, 0, 1};
        
        glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);			
        glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);			
        glLightfv(GL_LIGHT1, GL_POSITION, LightPosition);		
        glEnable(GL_LIGHT1);
        
        //Calculate the normals
        CalcNorms();
      
      glutMainLoop();
}
