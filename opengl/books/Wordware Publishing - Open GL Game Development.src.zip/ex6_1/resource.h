//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by me.rc
//
#define IDR_MENU                        101
#define IDR_POPUP_MENU                  103
#define IDD_MAP_DETAILS                 104
#define IDC_MAP_DETAILS_NAME            1000
#define IDC_MAP_DETAILS_LEVEL_RULES     1001
#define IDC_MAP_DETAILS_LEVEL_TYPE      1002
#define ID_FILE_EXIT                    40001
#define ID_DRAWING_WIREFRAME            40002
#define ID_DRAWING_SOLID                40003
#define ID_POPUP_TEXTURE                40004
#define ID_POPUP_DELETE                 40005
#define ID_POPUP_DUPLICATE              40006
#define ID_POPUP_MOVE                   40007
#define ID_MAP_DETAILS                  40009
#define ID_LAYERS_CEILING               40012
#define ID_LAYERS_WALL                  40013
#define ID_LAYERS_FLOOR                 40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
